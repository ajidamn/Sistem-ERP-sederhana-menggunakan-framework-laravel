<footer class="main-footer">
    <strong>Copyright &copy; 2022 <a href="https://nusapratama.co.id/">CV. Nusa Pratama Anugerah</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0
    </div>
  </footer><?php /**PATH I:\Laravel\NPA\resources\views/layout/footer.blade.php ENDPATH**/ ?>