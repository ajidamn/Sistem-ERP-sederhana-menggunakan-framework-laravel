<!DOCTYPE html>
<html lang="en">
  <?php echo $__env->make('layout/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/css/buttons.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/select2/css/select2.min.css">
  <body class="hold-transition sidebar-mini">
    <div class="wrapper">
      <!-- Preloader -->
      <div class="preloader flex-column justify-content-center align-items-center">
        <img class="animation__shake" src="<?php echo e(asset('img')); ?>/logo.png" alt="AdminLTELogo" height="60" width="60">
        
        <h4><b> Nusa Pratama Anugerah </b></h4>
      </div> 
      <!-- Navbar -->
      <?php echo $__env->make('layout/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- /.navbar -->

      <!-- Main Sidebar Container -->
      <?php echo $__env->make('layout/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1>Surat Jalan</h1>
              </div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="dashboard">Home</a></li>
                  <li class="breadcrumb-item active">Surat Jalan</li>
                </ol>
              </div>
            </div>
          </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <button type="button" id="tambahdata" data-toggle="modal" data-target="#modal-tambah" data-backdrop="static" class="btn bg-gradient-primary">Tambah Surat Jalan</button>
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body table-responsive">
                    <table id="tabel-sj" class="table table-bordered table-striped">
                      <thead>
                      <tr>
                        <th>Action</th>
                        <th>No SO</th>
                        <th>Konsumen</th>
                        <th>Tanggal Kirim</th>
                        <th>Tanggal Terima</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                      </tr>
                      </thead>
                      <tbody>
                      
                      </tbody>
                    </table>
                  </div>
                  <!-- /.card-body -->
                </div>
                <!-- /.card -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div>
          <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
      </div>
      <!-- /.content-wrapper -->
      <?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- MODAL -->
      <!-- MODAL Tambah Surat Jalan -->
        <div class="modal fade" id="modal-tambah">
          <div class="modal-dialog modal-lg">
              <div class="modal-content">
                      <div class="modal-header bg-primary">
                          <h4 class="modal-title">Buat Surat Jalan</h4>
                          <button type="button" id="btn-x-sj" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                          </button>
                      </div>
                      <div class="modal-body form-group">
                          <div class="row">
                            <div class="col-lg-12">
                              <div class="row">
                                <div class="col-lg-4">
                                  <label>Tipe </label>
                                  <select id="tmb-tipe-sj"  class="form-control"  required>
                                    <option value="">Pilih Jenis Surat Jalan</option>
                                    <option value="41">PENJUALAN</option>
                                    <option value="42">PEMAKAIAN</option>
                                    <option value="43">PRODUKSI</option>
                                    <option value="44">SPPB</option>
                                  </select>
                                </div>
                                <div class="col-lg-4">
                                  <label>Kode SJ</label>
                                  <input id="tmb-kode-sj" class="form-control" type="text" value=""readonly required>
                                </div>
                                <div class="col-lg-4">
                                  <label>Tanggal</label>
                                  <input id="tmb-tgl-sj" class="form-control" type="date" required>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-lg-4">
                                  <div id="tmb-so">
                                    <label> Nomor Sales Order</label>
                                    <select id="tmb-so-sj"  class="form-control select2 " style="width:100% ;">
                                    </select>
                                    <label>Konsumen</label>
                                    <input type="text" id="tmb-konsumen-sj" hidden>
                                    <input type="text" id="tmb-namakonsumen-sj" class="form-control">
                                    <label>TGL Pengiriman</label>
                                    <input type="date" id="tmb-tglkirim-sj" class="form-control">
                                  </div>
                                  <div id="tmb-pakai">
                                    <label > Keterangan</label>
                                    <textarea  id="tmb-ketpakai-sj" class="form-control" row="2" style="resize: none;" ></textarea>
                                  </div>
                                  <div id="tmb-produksi">
                                    <label > Keterangan</label>
                                    <textarea  id="tmb-ketproduksi-sj" class="form-control" row="2" style="resize: none;" ></textarea>
                                  </div>
                                </div>
                                <div class="col-lg-4">
                                  <div id="tmb-so1">
                                    <label> Kota Tujuan</label>
                                    <input type="text" id="tmb-kota-sj" class="form-control">
                                    <label >Nopol Kendaraan</label>
                                    <input type="text" id="tmb-nopol-sj" class="form-control">
                                    <label> Alamat Pengiriman</label>
                                    <textarea  id="tmb-alamat-sj" class="form-control" row="2" style="resize: none;" ></textarea>
                                  </div>
                                </div>
                                <div class="col-lg-4">
                                  <div id="tmb-so2">
                                    <label>Ekspedisi</label>
                                    <input type="text" id="tmb-ekspedisi-sj" class="form-control">
                                    <label >no. Pengiriman</label>
                                    <input type="text" id="tmb-nokirim-sj" class="form-control">
                                    <label>Keterangan</label>
                                    <textarea  id="tmb-keterangan-sj" class="form-control" row="2" style="resize: none;" ></textarea>
                                  </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-lg-8"></div>
                                <div class="col-lg-4">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input form-control" id="kunci-sj">
                                    <label class="custom-control-label" for="kunci-sj" >Kunci SJ</label>
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                          </div>
                          <br>
                          <div class="row">
                            <div class="col-lg-12">
                              <div class="card card-outline card-primary">
                                <div class="card-header">
                                  <div class="row">
                                    <button id="btn-add-barang" class="btn btn-primary">Tambah Barang</button>
                                  </div>
                                  <div class="row" id="tambah-barang">
                                    <form id="form-tambah-barang">
                                      <div class="row">
                                        <div class="col-lg-4">
                                            <label>Nama Barang</label>
                                            <select id="tambah-nama-barang" class="form-control select2" style="width:100% ;" required></select>
                                            <label>Gudang</label>
                                            <select id="tambah-gudang-barang" class="form-control select2" style="width:100% ;" required></select>
                                            <label>Nama Request</label>
                                            <input id="tambah-namareq-barang" class="form-control" type="text">
                                        </div>
                                        <div class="col-lg-2">
                                          <label>Stock</label>
                                          <input id="tambah-stock-barang" class="form-control" type="number" min="1" required readonly>
                                          <label> Satuan</label>
                                          <input id="tambah-satuan-barang" class="form-control" type="text" readonly>
                                        </div>
                                        <div class="col-lg-2">
                                          <label>QTY</label>
                                          <input id="tambah-qty-barang" class="form-control" type="number" min="1" required >  
                                        </div>
                                        <div class="col-lg-4">
                                          <label>Keterangan</label>
                                          <textarea id="tambah-keterangan-barang" class="form-control" row="3" style="resize: none;" placeholder="Keterangan Produk" ></textarea>
                                          <br>
                                          <button type="submit" id="btn-tambah-barang" class=" form-control btn btn-primary ">Tambah Barang</button>
                                        </div>
                                      </div>
                                    </form>
                                  </div>
                                  <div class="row" id="edit-barang">
                                    <form id="edit-tambah-barang">
                                      <div class="row">
                                        <div class="col-lg-4">
                                            <label>Gudang</label>
                                            <input type="text" id="edit-kode-barang" hidden>
                                            <input type="text"id="edit-gudang-barang" class="form-control" disabled>
                                            <label>Nama Barang</label>
                                            <input type="text"id="edit-nama-barang" class="form-control" disabled>
                                            <label>Nama Request</label>
                                            <input type="text" id="edit-namareq-barang" class="form-control">
                                        </div>
                                        <div class="col-lg-2">
                                          <label>Stock</label>
                                          <input id="edit-stock-barang" class="form-control" type="number" min="1" required readonly>
                                          <label> Satuan</label>
                                          <input id="edit-satuan-barang" class="form-control" type="text" readonly>
                                        </div>
                                        <div class="col-lg-2">
                                          <label>QTY</label>
                                          <input id="edit-qty-barang" class="form-control" type="number" min="1" required >  
                                        </div>
                                        <div class="col-lg-4">
                                          <label>Keterangan</label>
                                          <textarea id="edit-keterangan-barang" class="form-control" row="3" style="resize: none;" placeholder="Keterangan Produk" ></textarea>
                                          <br>
                                          <div class="row justify-content-between">
                                            <button type="button"  id="btn-cancel-edit-barang" class="col-sm-5 form-control btn btn-default">Cancel</button>
                                            <button type="submit"  id="btn-edit-barang" class="col-sm-5 form-control btn btn-warning ">Edit Barang</button>
                                          </div>
                                        </div>
                                      </div>
                                    </form>
                                  </div>
                                  <div class="row" id="hapus-barang">
                                    <form id="form-hapus-barang">
                                      <input id="hapus-kode-barang" class="form-control" type="text" hidden>
                                      <div class="row justify-content-center ">
                                        <label> Apakah Anda yakin akan menghapus barang ini ??</label>
                                      </div>
                                      <div class="row justify-content-center" > 
                                            <label class="col-lg-3">Nama Barang </label>
                                            <label id ="hapus-nama-barang" class="col-lg-9"></label>
                                      </div>
                                      <br>
                                      <div class="row justify-content-between ">
                                        <button type="button"  id="btn-cancel-hapus" class="col-lg-5 form-control btn btn-default">Cancel</button>
                                        <button type="submit"  id="btn-hapus-barang" class="col-lg-5 form-control btn btn-danger ">Hapus Barang</button>
                                      </div>
                                    </form>
                                  </div>
                                </div>
                                <div class="card-body">
                                  <table  class="table table-responsive table-bordered table-striped">
                                    <thead>
                                    <tr>
                                      <th rowspan="2">Action</th>
                                      <th rowspan="2">No.</th>
                                      <th colspan="2">Lokasi Gudang Keluar</th>
                                      <th colspan="4">Barang</th>
                                      <th rowspan="2">QTY</th>
                                      <th rowspan="2">Uraian</th>
                                      <th colspan="2">Kode Akun Debit</th>
                                      <th colspan="2">Kode Akun Kredit</th>
                                    </tr>
                                    <tr>
                                      <td>Kode</td>
                                      <td>Nama</td>
                                      <td>Kode</td>
                                      <td>Nama</td>
                                      <td>Nama Request</td>
                                      <td>Satuan</td>
                                      <td>Kode</td>
                                      <td>Nama Perkiraan</td>
                                      <td>Kode</td>
                                      <td>Nama Perkiraan</td>
                                    </tr>
                                    </thead>
                                    <tbody id="tbl_sj_tambah">
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            </div>
                          </div>
                      </div>
                  <form id="tmbsj">
                      <input type="text" id="tmb-time-so" class="form-control" hidden>
                      <div class="modal-footer justify-content-between ">
                          <button type="button" id="btn-close-sj" class=" col-sm-2 btn btn-default" data-dismiss="modal">Close</button>
                          <button type="submit" id="btn-submit-sj"class="col-sm-2 form-control btn btn-primary">Tambah</button>
                      </div>
                  </form>
              </div>
          </div>
        </div>
      <!--/ Modal Tambah Surat Jalan -->
      <!-- MODAL Edit SUrat jalan -->
        <div class="modal fade" id="modal-edit">
          <div class="modal-dialog modal-lg">
              <div class="modal-content">
                  <div class="modal-header bg-warning">
                      <h4 class="modal-title">Edit Surat Jalan</h4>
                      <button type="button" id="btn-edit-x-sj" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                  </div>
                  <div class="modal-body form-group">
                    <div class="row">
                      <div class="col-lg-9">
                        <div class="row">
                          <div class="col-lg-4">
                            <label>Tipe </label>
                            <input type="text" id="edt-tipe-sj" class="form-control" disabled>
                          </div>
                          <div class="col-lg-4">
                            <label>Kode SJ</label>
                            <input id="edt-kode-sj" class="form-control" type="text" value=""readonly required>
                          </div>
                          <div class="col-lg-4">
                              
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-lg-4">
                            <div id="edt-so">
                              <label> Nomor Sales Order</label>
                              <input type="text" id="edt-so-sj" class="form-control" disabled>
                              <label>Konsumen</label>
                              <input type="text" id="edt-namakonsumen-sj" class="form-control" disabled>
                              <label>TGL Pengiriman</label>
                              <input type="date" id="edt-tglkirim-sj" class="form-control" >
                            </div>
                            <label>TGL Diterima</label>
                              <input type="date" id="edt-tglditerima-sj" class="form-control" >
                            <div id="edt-pakai">
                              <label > Keterangan</label>
                              <textarea  id="edt-ketpakai-sj" class="form-control" row="2" style="resize: none;" ></textarea>
                            </div>
                            <div id="edt-produksi">
                              <label > Keterangan</label>
                              <textarea  id="edt-ketproduksi-sj" class="form-control" row="2" style="resize: none;" ></textarea>
                            </div>
                          </div>
                          <div class="col-lg-4">
                            <div id="edt-so1">
                              <label> Kota Tujuan</label>
                              <input type="text" id="edt-kota-sj" class="form-control" >
                              <label >Nopol Kendaraan</label>
                              <input type="text" id="edt-nopol-sj" class="form-control" >
                              <label> Alamat Pengiriman</label>
                              <textarea  id="edt-alamat-sj" class="form-control" row="2" style="resize: none;" ></textarea>
                            </div>
                          </div>
                          <div class="col-lg-4">
                            <div id="edt-so2">
                              <label>Ekspedisi</label>
                              <input type="text" id="edt-ekspedisi-sj" class="form-control" >
                              <label >no. Pengiriman</label>
                              <input type="text" id="edt-nokirim-sj" class="form-control" >
                              <label>Keterangan</label>
                              <textarea  id="edt-keterangan-sj" class="form-control" row="2" style="resize: none;" ></textarea>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-3">
                        <label>AUTHORISASI </label>
                        <br>
                        <label >Dibuat Oleh :</label>
                        <h6 id="edit-nama-pembuat"></h6>
                        <h6 id="edit-create-pembuat"></h6>
                        <label> Diperiksa Oleh :</label>
                        <h6 id="edit-nama-pemeriksa"></h6>
                        <h6 id="edit-create-pemeriksa"></h6>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-lg-8"></div>
                      <div class="col-lg-4">
                      <div class="custom-control custom-switch">
                          <input type="checkbox" class="custom-control-input form-control" id="edt-kunci-sj">
                          <label class="custom-control-label" for="edt-kunci-sj" >Kunci SJ</label>
                        </div>
                      </div>
                    </div>
                    <br>
                    <div class="row">
                      <div class="col-lg-12">
                        <div class="card card-outline card-warning">
                          <div class="card-header">
                            <div class="row">
                              <button id="edt-btn-add-barang" class="btn btn-primary">Tambah Barang</button>
                            </div>
                            <div class="row" id="edt-tambah-barang">
                              <form id="edt-form-tambah-barang">
                                <div class="row">
                                  <div class="col-lg-4">
                                      <label>Gudang</label>
                                      <select id="edt-tambah-gudang-barang" class="form-control select2" style="width:100% ;" required></select>
                                      <label>Nama Barang</label>
                                      <select id="edt-tambah-nama-barang" class="form-control select2" style="width:100% ;" required></select>
                                      <label>Nama Request</label>  
                                      <input id="edt-tambah-namareq-barang" class="form-control" type="text">
                                  </div>
                                  <div class="col-lg-2">
                                    <label>Stock</label>
                                    <input id="edt-tambah-stock-barang" class="form-control" type="number" min="1" required readonly>
                                    <label> Satuan</label>
                                    <input id="edt-tambah-satuan-barang" class="form-control" type="text" readonly>
                                  </div>
                                  <div class="col-lg-2">
                                    <label>QTY</label>
                                    <input id="edt-tambah-qty-barang" class="form-control" type="number" min="1" required >  
                                  </div>
                                  <div class="col-lg-4">
                                    <label>Keterangan</label>
                                    <textarea id="edt-tambah-keterangan-barang" class="form-control" row="3" style="resize: none;" placeholder="Keterangan Produk" ></textarea>
                                    <br>
                                    <button type="submit" id="edt-btn-tambah-barang" class=" form-control btn btn-primary ">Tambah Barang</button>
                                  </div>
                                </div>
                              </form>
                            </div>
                            <div class="row" id="edt-edit-barang">
                              <form id="edt-edit-tambah-barang">
                                <div class="row">
                                  <div class="col-lg-4">
                                      <label>Gudang</label>
                                      <input type="text" id="edt-edit-kode-barang" hidden>
                                      <input type="text"id="edt-edit-gudang-barang" class="form-control" disabled>
                                      <label>Nama Barang</label>
                                      <input type="text"id="edt-edit-nama-barang" class="form-control" disabled>
                                      <label>Nama Request</label>  
                                      <input id="edt-edit-namareq-barang" class="form-control" type="text">
                                  </div>
                                  <div class="col-lg-2">
                                    <label>Stock</label>
                                    <input id="edt-edit-stock-barang" class="form-control" type="number" min="1" required readonly>
                                    <label> Satuan</label>
                                    <input id="edt-edit-satuan-barang" class="form-control" type="text" readonly>
                                  </div>
                                  <div class="col-lg-2">
                                    <label>QTY</label>
                                    <input id="edt-edit-qty-barang" class="form-control" type="number" min="1" required >  
                                  </div>
                                  <div class="col-lg-4">
                                    <label>Keterangan</label>
                                    <textarea id="edt-edit-keterangan-barang" class="form-control" row="3" style="resize: none;" placeholder="Keterangan Produk" ></textarea>
                                    <br>
                                    <div class="row justify-content-between">
                                      <button type="button"  id="edt-btn-cancel-edit-barang" class="col-sm-5 form-control btn btn-default">Cancel</button>
                                      <button type="submit"  id="edt-btn-edit-barang" class="col-sm-5 form-control btn btn-warning ">Edit Barang</button>
                                    </div>
                                  </div>
                                </div>
                              </form>
                            </div>
                            <div class="row" id="edt-hapus-barang">
                              <form id="edt-form-hapus-barang">
                                <input id="edt-hapus-kode-barang" class="form-control" type="text" hidden>
                                <div class="row justify-content-center ">
                                  <label> Apakah Anda yakin akan menghapus barang ini ??</label>
                                </div>
                                <div class="row justify-content-center" > 
                                      <label class="col-lg-3">Nama Barang </label>
                                      <label id ="edt-hapus-nama-barang" class="col-lg-9"></label>
                                </div>
                                <br>
                                <div class="row justify-content-between ">
                                  <button type="button"  id="edt-btn-cancel-hapus" class="col-lg-5 form-control btn btn-default">Cancel</button>
                                  <button type="submit"  id="edt-btn-hapus-barang" class="col-lg-5 form-control btn btn-danger ">Hapus Barang</button>
                                </div>
                              </form>
                            </div>
                          </div>
                          <div class="card-body">
                          <table  class="table table-responsive table-bordered table-striped">
                              <thead>
                              <tr>
                                <th rowspan="2">No.</th>
                                <th colspan="2">Lokasi Gudang Keluar</th>
                                <th colspan="4">Barang</th>
                                <th rowspan="2">QTY</th>
                                <th rowspan="2">Uraian</th>
                                <th colspan="2">Kode Akun Debit</th>
                                <th colspan="2">Kode Akun Kredit</th>
                              </tr>
                              <tr>
                                <td>Kode</td>
                                <td>Nama</td>
                                <td>Kode</td>
                                <td>Nama</td>
                                <td>Nama Request</td>
                                <td>Satuan</td>
                                <td>Kode</td>
                                <td>Nama Perkiraan</td>
                                <td>Kode</td>
                                <td>Nama Perkiraan</td>
                              </tr>
                              </thead>
                              <tbody id="tbl_sj_edit">
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <form id="edtsj">
                    <input type="text" id="edt-edit-time-sj" hidden>
                      <div class="modal-footer justify-content-between ">
                          <button type="button" id="edt-btn-close-sj" class=" col-sm-2 btn btn-default" data-dismiss="modal">Close</button>
                          <button type="submit" id="edt-btn-submit-sj"class="col-sm-2 form-control btn btn-warning">Edit</button>
                      </div>
                  </form>
              </div>
          </div>
        </div>
      <!--/ Modal Edit Sales Order -->
      <!-- MODAL Detail Sales Order -->
        <div class="modal fade" id="modal-detail">
          <div class="modal-dialog modal-lg">
              <div class="modal-content">
                  <div class="modal-header bg-info">
                      <h4 class="modal-title">Detail Surat Jalan</h4>
                      <button type="button" id="btn-detail-x-sj" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                  </div>
                  <div class="modal-body form-group">
                    <div class="row">
                      <div class="col-lg-9">
                        <div class="row">
                          <div class="col-lg-4">
                            <label>Tipe </label>
                            <input type="text" id="detail-tipe-sj" class="form-control" disabled>
                          </div>
                          <div class="col-lg-4">
                            <label>Kode SJ</label>
                            <input id="detail-kode-sj" class="form-control" type="text" value=""readonly required>
                          </div>
                          <div class="col-lg-4">
                            <label>Tanggal</label>
                            <input id="detail-tgl-sj" class="form-control" type="date" disabled required>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-lg-4">
                            <div id="detail-so">
                              <label> Nomor Sales Order</label>
                              <input type="text" id="detail-so-sj" class="form-control" disabled>
                              <label>Konsumen</label>
                              <input type="text" id="detail-namakonsumen-sj" class="form-control" disabled>
                              <label>TGL Pengiriman</label>
                              <input type="date" id="detail-tglkirim-sj" class="form-control" disabled>
                            </div>
                            <div id="detail-pakai">
                              <label > Keterangan</label>
                              <textarea  id="detail-ketpakai-sj" class="form-control" row="2" style="resize: none;" disabled></textarea>
                            </div>
                            <div id="detail-produksi">
                              <label > Keterangan</label>
                              <textarea  id="detail-ketproduksi-sj" class="form-control" row="2" style="resize: none;" disabled></textarea>
                            </div>
                          </div>
                          <div class="col-lg-4">
                            <div id="detail-so1">
                              <label> Kota Tujuan</label>
                              <input type="text" id="detail-kota-sj" class="form-control" disabled>
                              <label >Nopol Kendaraan</label>
                              <input type="text" id="detail-nopol-sj" class="form-control" disabled>
                              <label> Alamat Pengiriman</label>
                              <textarea  id="detail-alamat-sj" class="form-control" row="2" style="resize: none;" disabled></textarea>
                            </div>
                          </div>
                          <div class="col-lg-4">
                            <div id="detail-so2">
                              <label>Ekspedisi</label>
                              <input type="text" id="detail-ekspedisi-sj" class="form-control" disabled>
                              <label >no. Pengiriman</label>
                              <input type="text" id="detail-nokirim-sj" class="form-control" disabled>
                              <label>Keterangan</label>
                              <textarea  id="detail-keterangan-sj" class="form-control" row="2" style="resize: none;" disabled></textarea>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-3">
                        <label>AUTHORISASI </label>
                        <br>
                        <label >Dibuat Oleh :</label>
                        <h6 id="detail-nama-pembuat"></h6>
                        <h6 id="detail-create-pembuat"></h6>
                        <label> Diperiksa Oleh :</label>
                        <h6 id="detail-nama-pemeriksa"></h6>
                        <h6 id="detail-create-pemeriksa"></h6>
                      </div>
                    </div>
                    <br>
                    <div class="row">
                      <div class="col-lg-12">
                        <div class="card card-outline card-info">
                          <div class="card-header">
                            <div class="row justify-content-between col-lg-12">
                              <label> Detail Barang Surat Jalan </label>
                              <a id="cetak-sj" rel="noopener" target="_blank" class="col-sm-2 form-control btn btn-danger""><i class="fas fa-print"></i> Print</a>
                            </div>
                          </div>
                          <div class="card-body">
                          <table  class="table table-responsive table-bordered table-striped">
                              <thead>
                              <tr>
                                <th rowspan="2">No.</th>
                                <th colspan="2">Lokasi Gudang Keluar</th>
                                <th colspan="4">Barang</th>
                                <th rowspan="2">QTY</th>
                                <th rowspan="2">Uraian</th>
                                <th colspan="2">Kode Akun Debit</th>
                                <th colspan="2">Kode Akun Kredit</th>
                              </tr>
                              <tr>
                                <td>Kode</td>
                                <td>Nama</td>
                                <td>Kode</td>
                                <td>Nama</td>
                                <td>Nama Request</td>
                                <td>Satuan</td>
                                <td>Kode</td>
                                <td>Nama Perkiraan</td>
                                <td>Kode</td>
                                <td>Nama Perkiraan</td>
                              </tr>
                              </thead>
                              <tbody id="tbl_sj_detail">
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <form id="dtlsj">
                      <div class="modal-footer justify-content-between ">
                          <button type="button" id="btn-detail-close-sj" class=" col-sm-2 btn btn-default" data-dismiss="modal">Close</button>
                          <button type="submit" id="btn-detail-submit-sj"class="col-sm-2 form-control btn btn-success">Konfirmasi</button>
                      </div>
                  </form>
              </div>
          </div>
        </div>
      <!--/ Modal Detail Sales Order -->
        
      <!-- MODAL Hapus Sales Order -->
        <div class="modal fade" id="modal-hapus">
          <div class="modal-dialog modal-sm">
              <form id="form-hapus-sj">
                  <div class="modal-content">
                      <div class="modal-header bg-danger">
                          <h4 class="modal-title">Hapus Data SJ</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                          </button>
                      </div>
                      <div class="modal-body">
                          <div class="row">
                              <div class="col-lg-12">
                                  <div class="form-group">
                                      Apakah Anda Yakin Akan Menghapus Data ini ?
                                      <input id="hapus-kode-sj" class="form-control" type="text" hidden >
                                      <div class="row">
                                          <label class="col-md-3">Kode </label> 
                                          <h6 class="col-md-6" id="hapus-kode"></h6>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="modal-footer justify-content-between ">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          <button type="submit" id="btn-hapus" class=" col-sm-4 form-control btn btn-danger">Hapus</button>
                      </div>
                  </div>
              </form>
          </div>
        </div>
      <!--/ Modal Hapus Sales Order -->
      
    <!--/ MODAL -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/jquery/jquery.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/jquery-ui/jquery-ui.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables  & Plugins -->
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/jszip/jszip.min.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/pdfmake/pdfmake.min.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/pdfmake/vfs_fonts.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.colVis.min.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/select2/js/select2.full.min.js"></script>
    <script src="<?php echo e(asset('AdminLTE/plugins')); ?>/sweetalert2/sweetalert2.min.js"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('AdminLTE/dist')); ?>/js/adminlte.js"></script>
    <!-- AdminLTE for demo purposes -->
    <!-- Page specific script -->
    <script>
      $(document).ready(function() {   
        $('#tabel-sj').DataTable({
          'paging'      : true,
          'lengthChange': true,
          'searching'   : true,
          'ordering'    : true,
          'info'        : true,
          'autoWidth'   : false,
          "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"],
            processing: true,
            serverSide: true,
            ajax: '<?php echo url("data-sj"); ?>',
            columns: [   
                { data: 'action', name: 'action',orderable:false, searchable:false},
                { data: 'kode', name: 'kode',orderable:true},
                { data: 'nama',name: 'nama',orderable:true},
                { data: 'tgl_kirim', name: 'tgl_kirim',orderable:true},
                { data: 'tgl_diterima', name: 'tgl_diterima',orderable:true},
                { data: 'keterangan', name: 'keterangan',orderable:true},
                { data: 'status', name: 'status',orderable:true},
            ]
        });
        
      }); 
      $('.select2').select2();
      
      
      // Tambah SJ
        $(document).on('click','#tambahdata',function(){
          $('#tmb-so').hide(); $('#tmb-so1').hide(); $('#tmb-so2').hide();
          $('#tmb-pakai').hide();$('#tmb-produksi').hide();
          $('#btn-add-barang').hide();$('#tambah-barang').hide();$('#edit-barang').hide();$('#hapus-barang').hide();
          $('#alamatbaru').prop('hidden',false);
          $('#tmb-tgl-sj').val(''); $('#tmb-tipe-sj').val(''); $('#tmb-konsumen-sj').val(''); $('#tmb-namakonsumen-sj').val(''); $('#tmb-nopol-sj').val(''); $('#tmb-ekspedisi-sj').val('');
          $('#tmb-kode-sj').val(''); $('#tmb-so-sj').val(''); $('#tmb-tglkirim-sj').val('');$('#tmb-kota-sj').val(''); $('#tmb-alamat-sj').val(''); $('#tmb-alamatbaru-sj').val('');
          $('#btn-x-sj').prop('disabled',false); $('#btn-close-sj').prop('disabled',false); $('#btn-submit-sj').prop('disabled',true); 
          $('#tmb-so-sj').prop('disabled',false); $('#tmb-namakonsumen-sj').prop('disabled',true); $('#tmb-tglkirim-sj').prop('disabled',false); $('#tmb-kota-sj').prop('disabled',false); $('#tmb-ketpakai-sj').prop('disabled',false); $('#tmb-ketproduksi-sj').prop('disabled',false);
          $('#tmb-nopol-sj').prop('disabled',false); $('#tmb-ekspedisi-sj').prop('disabled',false); $('#tmb-nokirim-sj').prop('disabled',false); $('#tmb-keterangan-sj').prop('disabled',false);

        });
        $('#tmb-tipe-sj').on('change',function(){
          var tipe = $(this).val();
          var today = new Date();
          var tgl = today.getDate();
          if(tgl == 1 || tgl == 2 || tgl == 3 || tgl == 4 || tgl == 5 || tgl == 6 || tgl == 7 || tgl == 8 || tgl == 9){
            tgl = '0'+tgl;
          }
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+tgl;
          $('#tmb-tglkirim-sj').val(date);
          if(tipe == 41){
            $('#tmb-so').show(); $('#tmb-so1').show(); $('#tmb-so2').show();
            $('#tmb-pakai').hide();$('#tmb-produksi').hide();
            $('#tmb-so-sj').select2({
              placeholder: 'Pilih Sales Order',
              ajax: {
                  url: '<?php echo url("dropdown-so-sj"); ?>',
                  dataType: 'json',
                  processResults: function (data) {
                      return {
                          results: $.map(data, function (item) {
                              return {
                                  text: item.kode,
                                  id: item.kode
                              }
                          })
                      };
                  },
                  cache: true
              }
            });
            
            var tgl = $('#tmb-tgl-sj').val();
            var th = tgl.substr(2,2);
            var bln = tgl.substr(5,2);
            var dy = tgl.substr(8,2);
            var n = th+bln+dy;
            $.ajax({
              url     :'<?php echo url("lastkode-sj"); ?>',
              type    : 'get',
              data    : {
                jenis   : tipe,
                tanggal : n
              },
              success : function(data){
                $('#tmb-kode-sj').val(data);
              }
            });
          } else if( tipe == 42){
            $('#tmb-so').hide(); $('#tmb-so1').hide(); $('#tmb-so2').hide();
            $('#tmb-pakai').show();$('#tmb-produksi').hide();
            var tgl = $('#tmb-tgl-sj').val();
            var th = tgl.substr(2,2);
            var bln = tgl.substr(5,2);
            var dy = tgl.substr(8,2);
            var n = th+bln+dy;
            $.ajax({
              url     :'<?php echo url("lastkode-sj"); ?>',
              type    : 'get',
              data    : {
                jenis   : tipe,
                tanggal : n
              },
              success : function(data){
                $('#tmb-kode-sj').val(data);
              }
            });
          } else if(tipe == 43){
            $('#tmb-so').hide(); $('#tmb-so1').hide(); $('#tmb-so2').hide();
            $('#tmb-pakai').hide();$('#tmb-produksi').show();
            var tgl = $('#tmb-tgl-sj').val();
            var th = tgl.substr(2,2);
            var bln = tgl.substr(5,2);
            var dy = tgl.substr(8,2);
            var n = th+bln+dy;
            $.ajax({
              url     :'<?php echo url("lastkode-sj"); ?>',
              type    : 'get',
              data    : {
                jenis   : tipe,
                tanggal : n
              },
              success : function(data){
                $('#tmb-kode-sj').val(data);
              }
            });
          } else if(tipe == 44){
            $('#tmb-so').hide(); $('#tmb-so1').hide(); $('#tmb-so2').hide();
            $('#tmb-pakai').hide();$('#tmb-produksi').hide();
            var tgl = $('#tmb-tgl-sj').val();
            var th = tgl.substr(2,2);
            var bln = tgl.substr(5,2);
            var dy = tgl.substr(8,2);
            var n = th+bln+dy;
            $.ajax({
              url     :'<?php echo url("lastkode-sj"); ?>',
              type    : 'get',
              data    : {
                jenis   : tipe,
                tanggal : n
              },
              success : function(data){
                $('#tmb-kode-sj').val(data);
              }
            });
          } else {
            $('#tmb-so').hide(); $('#tmb-so1').hide(); $('#tmb-so2').hide();
            $('#tmb-pakai').hide();$('#tmb-produksi').hide();
            $('tmb-kode-sj').val('');
          }
        });
        $(document).on('change','#tmb-tgl-sj', function(){
          
          var tipe = $('#tmb-tipe-sj').val();
          var tgl = $('#tmb-tgl-sj').val();
          var th = tgl.substr(2,2);
          var bln = tgl.substr(5,2);
          var dy = tgl.substr(8,2);
          var n = th+bln+dy;
          $.ajax({
            url     :'<?php echo url("lastkode-sj"); ?>',
            type    : 'get',
            data    : {
              jenis   : tipe,
              tanggal : n
            },
            success : function(data){
              $('#tmb-kode-sj').val(data);
            }
          });
        });
        $(document).on('change','#tmb-so-sj', function(){
          var so = $(this).val();
          $.ajax({
            url     :'<?php echo url("data-so/'+so+'/edit"); ?>',
            type    : 'get',
            success : function(data){
             console.log(data);
             $('#tmb-namakonsumen-sj').val(data.so.rekanan);
             $('#tmb-konsumen-sj').val(data.so.konsumen);
             $('#tmb-alamat-sj').val(data.so.alamat);
            }
          });
        });

        $(document).on('change','#kunci-sj', function(){
          
          var checkBox = document.getElementById("kunci-sj");
          var token = "<?php echo csrf_token(); ?>";
          var kode  = $('#tmb-kode-sj').val();
          var length = kode.length;
          var today = new Date();
          var tgl = today.getDate();
          if(tgl == 1 || tgl == 2 || tgl == 3 || tgl == 4 || tgl == 5 || tgl == 6 || tgl == 7 || tgl == 8 || tgl == 9){
            tgl = '0'+tgl;
          }
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+tgl;
          var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
          var time = date+' '+time;
          var tipe = $('#tmb-tipe-sj').val();
          var tgl = $('tmb-tgl-sj').val();
          if (kode == ''||tgl == ''|| length != 21){
            Toast.fire({
              icon: 'error',
              title: 'TANGGAL WAJIB DIISI !!'
            })
            return false;
          }
          if(tipe == 41){
            var so = $('#tmb-so-sj').val(); var konsumen = $('#tmb-namakonsumen-sj').val(); var tglkirim = $('#tmb-tglkirim-sj').val(); var kota = $('#tmb-kota-sj').val(); 
            var nopol = $('#tmb-nopol-sj').val(); var alamat = $('#tmb-alamat-sj').val(); var ekspedisi = $('#tmb-ekspedisi-sj').val(); var resi = $('#tmb-nokirim-sj').val(); var ket = $('#tmb-keterangan-sj').val();

            if (so == ''||konsumen ==''||tglkirim == ''||tglkirim == ''||kota == ''||ket == ''||alamat == '' ){
              Toast.fire({
                icon: 'error',
                title: 'SEMUA INPUTAN WAJIB DIISI !!'
              })
              return false;
            } else {
              if(checkBox.checked == true){
                //TURN ON
                $('#btn-x-sj').prop('disabled',true); $('#btn-close-sj').prop('disabled',true); $('#btn-submit-sj').prop('disabled',false); 
                $('#tmb-so-sj').prop('disabled',true); $('#tmb-namakonsumen-sj').prop('disabled',true); $('#tmb-tglkirim-sj').prop('disabled',true); $('#tmb-kota-sj').prop('disabled',true); 
                $('#tmb-nopol-sj').prop('disabled',true); $('#tmb-alamat-sj').prop('disabled',true); $('#tmb-ekspedisi-sj').prop('disabled',true); $('#tmb-nokirim-sj').prop('disabled',true); $('#tmb-keterangan-sj').prop('disabled',true);
                $('#btn-add-barang').show();
                $('#tbl-sj-tambah').empty();
              } else {
                //TURN OFF
                $('#btn-x-sj').prop('disabled',false); $('#btn-close-sj').prop('disabled',false); $('#btn-submit-sj').prop('disabled',true); 
                $('#tmb-so-sj').prop('disabled',false); $('#tmb-namakonsumen-sj').prop('disabled',true); $('#tmb-tglkirim-sj').prop('disabled',false); $('#tmb-kota-sj').prop('disabled',false); 
                $('#tmb-nopol-sj').prop('disabled',false); $('#tmb-alamat-sj').prop('disabled',true); $('#tmb-ekspedisi-sj').prop('disabled',false); $('#tmb-nokirim-sj').prop('disabled',false); $('#tmb-keterangan-sj').prop('disabled',false);
                $('#btn-add-barang').hide();
                $('#tambah-barang').hide();
                $('#edit-barang').hide();
                $('#hapus-barang').hide();
                $('#tbl-sj-tambah').empty();
                $.ajax({
                  type  :'delete',
                  url: '<?php echo url("hps-detail-sj/'+kode+'"); ?>',
                  data :{
                    _token : token,
                  },
                  success:function(response){
                    if (response == 'Data Berhasil Dihapus'){
                      Toast.fire({
                        icon: 'success',
                        title: response
                      })
                    } else {
                      Toast.fire({
                        icon: 'error',
                        title: response
                      })
                    }
                  }
                });
              }
            }
          } else if (tipe == 42){
            var ket = $('#tmb-ketpakai-sj').val();
            if(ket ==''){
              Toast.fire({
                icon: 'error',
                title: 'KETERANGAN WAJIB DIISI !!'
              })
              return false;
            } else {
              if(checkBox.checked == true){
                //TURN ON
                $('#btn-x-sj').prop('disabled',true); $('#btn-close-sj').prop('disabled',true); $('#btn-submit-sj').prop('disabled',false); 
                $('#tmb-tipe-sj').prop('disabled',true);$('#tmb-tgl-sj').prop('disabled',true);$('#tmb-ketpakai-sj').prop('disabled',true);
                $('#btn-add-barang').show();
                $('#tbl-sj-tambah').empty();
              } else {
                //TURN OFF
                $('#tmb-tipe-sj').prop('disabled',false);$('#tmb-tgl-sj').prop('disabled',false);$('#tmb-ketpakai-sj').prop('disabled',false);
                $('#btn-x-sj').prop('disabled',false);$('#btn-close-sj').prop('disabled',false);$('#btn-submit-sj').prop('disabled',true); 
                $('#btn-add-barang').hide();
                $('#tambah-barang').hide();
                $('#edit-barang').hide();
                $('#hapus-barang').hide();
                $('#tbl-sj-tambah').empty();
                $.ajax({
                  type  :'delete',
                  url: '<?php echo url("hps-detail-sj/'+kode+'"); ?>',
                  data :{
                    _token : token,
                  },
                  success:function(response){
                    if (response == 'Data Berhasil Dihapus'){
                      Toast.fire({
                        icon: 'success',
                        title: response
                      })
                    } else {
                      Toast.fire({
                        icon: 'error',
                        title: response
                      })
                    }
                  }
                });
              }
            }
          } else if (tipe == 43){
            var ket = $('#tmb-ketproduksi-sj').val();
            if(ket==''){
              Toast.fire({
                icon: 'error',
                title: 'KETERANGAN WAJIB DIISI !!'
              })
            } else {
              if(checkBox.checked == true){
                //TURN ON
                $('#tmb-tipe-sj').prop('disabled',true);$('#tmb-tgl-sj').prop('disabled',true);$('#tmb-ketprpduksi-sj').prop('disabled',true);
                $('#btn-x-sj').prop('disabled',true);$('#btn-close-sj').prop('disabled',true);$('#btn-submit-sj').prop('disabled',false); 
                $('#btn-add-barang').show();
                $('#tbl-sj-tambah').empty();
              } else {
                //TURN OFF
                $('#tmb-tipe-sj').prop('disabled',false);$('#tmb-tgl-sj').prop('disabled',false);$('#tmb-ketproduksi-sj').prop('disabled',false);
                $('#btn-x-sj').prop('disabled',false);$('#btn-close-sj').prop('disabled',false);$('#btn-submit-sj').prop('disabled',true); 
                $('#btn-add-barang').hide();
                $('#tambah-barang').hide();
                $('#edit-barang').hide();
                $('#hapus-barang').hide();
                $('#tbl-sj-tambah').empty();
                $.ajax({
                  type  :'delete',
                  url   : '<?php echo e("hapus-detailsj/'+kode+'"); ?>',
                  success:function(response){
                    if (response == 'Data Berhasil Dihapus'){
                      Toast.fire({
                        icon: 'success',
                        title: response
                      })
                    } else {
                      Toast.fire({
                        icon: 'error',
                        title: response
                      })
                    }
                  }
                });
              }
            }
          } else {
            alert('Pilih Tipe Surat Jalan !!');
            checkBox.prop('checked',false);
            return false;
          }
        });
        //Tambah Barang
          $(document).on('click','#btn-add-barang', function(){
            $('#tambah-barang').show();
            $('#btn-add-barang').hide();
            document.getElementById("form-tambah-barang").reset();
            $('#tambah-gudang-barang').empty();
            $('#tambah-nama-barang').empty();
            var tipe = $('#tmb-tipe-sj').val();
            if (tipe == 41){
              var so = $('#tmb-so-sj').val();
              $('#tambah-nama-barang').select2({
                placeholder: 'Pilih Barang',
                ajax: {
                    url: '<?php echo url("dropdown-barangso/'+so+'"); ?>',
                    dataType: 'json',
                    processResults: function (data) {
                        return {
                            results: $.map(data, function (item) {
                                return {
                                    text: item.nama,
                                    id: item.kode
                                }
                            })
                        };
                    },
                    cache: true
                }
              });
            } else {
              $('#tambah-nama-barang').select2({
                placeholder: 'Pilih Barang',
                ajax: {
                    url: '<?php echo url("dropdown-barang"); ?>',
                    dataType: 'json',
                    processResults: function (data) {
                        return {
                            results: $.map(data, function (item) {
                                return {
                                    text: item.nama,
                                    id: item.kode
                                }
                            })
                        };
                    },
                    cache: true
                }
              });
            }
            
            
          });
          
          $('#tambah-nama-barang').on('change', function (){
            var barang = $(this).val();
            $('#tambah-gudang-barang').empty();
            var so = $('#tmb-so-sj').val();
            var tipe = $('#tmb-tipe-sj').val();
            if( tipe == 41){
              $.ajax({
                url :'<?php echo url("data-detailsobarang/'+so+'"); ?>',
                type : 'get',
                data  :{
                  barang : barang,
                },
                success : function(data){
                  console.log(data);
                  if(data.nama_request == null){
                    
                    $('#tambah-satuan-barang').val(data.satuan);
                    $('#tambah-qty-barang').val(data.qty);
                    $('#tambah-keterangan-barang').val(data.keterangan);
                  } else {
                    $('#tambah-namareq-barang').val(data.nama_request);
                    $('#tambah-satuan-barang').val(data.satuan);
                    $('#tambah-qty-barang').val(data.qty);
                    $('#tambah-keterangan-barang').val(data.keterangan);
                  }      
                }
              });
            } else {
              $.ajax({
                url   :'<?php echo url("data-barang/'+barang+'/edit"); ?>',
                get   : 'get',
                success : function(data){
                  console.log(data);
                  $('#tambah-satuan-barang').val(data.result.satuan);
                }
              });
            }
            //SATUAN
            
            //GUDANG
            $('#tambah-gudang-barang').select2({
              placeholder: 'Pilih Gudang',
              ajax: {
                  url: '<?php echo url("gudangso/'+barang+'"); ?>',
                  dataType: 'json',
                  processResults: function (data) {
                      return {
                          results: $.map(data, function (item) {
                              return {
                                  text: item.nama,
                                  id: item.kode
                              }
                          })
                      };
                  },
                  cache: true
              }
            })
            
            //STOK
            
          });
          $(document).on('change','#tambah-gudang-barang', function(){
            var gudang = $(this).val();
            var barang = $('#tambah-nama-barang').val();
            console.log(barang+" "+gudang);
            $.ajax({
              url :'<?php echo url("stock-barangmr/'+gudang+'"); ?>',
              type : 'get',
              data :{
                barang : $('#tambah-nama-barang').val(),
              },
              success : function(response){
                console.log(response);
                $('#tambah-stock-barang').val(response);
                $('#tambah-qty-barang').prop('max',response);
              }
            });
          });
          $('#form-tambah-barang').submit(function(e){
            var qty = $('#tambah-qty-barang').val();
            var stock = $('#tambah-stock-barang').val();
            e.preventDefault(); // prevent actual form submit
            var el = $('#btn-tambah-barang');
            el.prop('disabled', true);
            setTimeout(function(){el.prop('disabled', false); }, 4000);
            var token = "<?php echo csrf_token(); ?>";
            var sj = $('#tmb-kode-sj').val();
            var today = new Date();
            var tgl = today.getDate();
            if(tgl == 1 || tgl == 2 || tgl == 3 || tgl == 4 || tgl == 5 || tgl == 6 || tgl == 7 || tgl == 8 || tgl == 9){
              tgl = '0'+tgl;
            }
            var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+tgl;
            var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
            var time = date+' '+time;
            $.ajax({
              type: 'post',
              url: '<?php echo url("data-detailsj"); ?>',
              data : {
                sj          : sj,
                barang      : $('#tambah-nama-barang').val(),
                nama        : $('#tambah-namareq-barang').val(),
                _token      : "<?php echo e(csrf_token()); ?>",
                gudang      : $('#tambah-gudang-barang').val(),
                stock       : stock,
                qty         : $('#tambah-qty-barang').val(),
                keterangan  : $('#tambah-keterangan-barang').val(),
                time        : time
              }, // serializes form input
              success:function(response) {
                console.log(response);
                if(response.error == ''){
                  var hasil = response.success;
                  Toast.fire({
                    icon: 'success',
                    title: hasil
                  })
                  tabelSJtambah(sj);
                  document.getElementById("form-tambah-barang").reset();
                  $('#tambah-barang').hide();
                  $('#btn-add-barang').show();
                } else {
                  Toast.fire({
                    icon: 'error',
                    title: response.error
                  })
                }
                
              }
            });
            
            
          });
        //Tambah Barang
        //Edit Barang
          $('body').on('click', '.editbarang', function () {
            $('#edit-barang').show();
            $('#tambah-barang').hide();
            $('#btn-add-barang').hide();
            $('#hapus-barang').hide();
            var kode = $(this).data('kode');
            console.log(kode);
            $.ajax({
              url :'<?php echo url("data-detailsj/'+kode+'/edit"); ?>',
              type : 'get',
              success : function(response){
                console.log(response);
                $('#edit-kode-barang').val(kode);
                $('#edit-gudang-barang').val(response.gudang);
                $('#edit-nama-barang').val(response.nama);
                $('#edit-namareq-barang').val(response.nama_request);
                $('#edit-qty-barang').val(response.qty);
                $('#edit-stock-barang').val(response.stock);
                $('#edit-satuan-barang').val(response.satuan);
                $('#edit-keterangan-barang').val(response.keterangan);
              }
            });
          });
          $('#btn-cancel-edit-barang').on('click',function(){
            $('#edit-barang').hide();
            $('#btn-add-barang').show();
          });
          $('#edit-tambah-barang').submit(function(e){
            e.preventDefault(); // prevent actual form submit
            var el = $('#btn-edit-barang');
            el.prop('disabled', true);
            setTimeout(function(){el.prop('disabled', false); }, 4000);
            var token = "<?php echo csrf_token(); ?>";
            var kode = $('#edit-kode-barang').val();
            var sj = $('#tmb-kode-sj').val();
            $.ajax({
              type: 'put',
              url: '<?php echo url("data-detailsj/'+kode+'"); ?>',
              data : {
                kode        : kode,
                _token      : token,
                nama        : $('#edit-namareq-barang').val(),
                qty         : $('#edit-qty-barang').val(),
                keterangan  : $('#edit-keterangan-barang').val(),
              }, // serializes form input
              success:function(response) {
                console.log(response);
                var hasil = response.success;
                Toast.fire({
                  icon: 'success',
                  title: hasil
                })
                tabelSJtambah(sj);
                document.getElementById("edit-tambah-barang").reset();
                $('#edit-barang').hide();
                $('#btn-add-barang').show();
              }
            });
          });
        // /Edit Barang
        // Hapus Barang
          $('body').on('click','.hapusbarang',function(){
            $('#edit-barang').hide();
            $('#tambah-barang').hide();
            $('#btn-add-barang').hide();
            $('#hapus-barang').show();
            var kode = $(this).data('kode');
            $.ajax({
              url :'<?php echo url("data-detailsj/'+kode+'/edit"); ?>',
              type : 'get',
              success : function(response){
                console.log(response);
                $('#hapus-kode-barang').val(kode);
                $('#hapus-nama-barang').html(response.nama);
              }
            });
          });
          $('#btn-cancel-hapus').on('click', function(){
            $('#hapus-barang').hide();
            $('#btn-add-barang').show();
          });
          $('#form-hapus-barang').submit(function(e){
            e.preventDefault(); // prevent actual form submit
            var el = $('#btn-hapus-barang');
            el.prop('disabled', true);
            setTimeout(function(){el.prop('disabled', false); }, 4000);
            var token = "<?php echo csrf_token(); ?>";
            var kode = $('#hapus-kode-barang').val();
            var sj = $('#tmb-kode-sj').val();
            $.ajax({
              type: 'delete',
              url: '<?php echo url("data-detailsj/'+kode+'"); ?>',
              data : {
                kode        : kode,
                _token      : token,
              }, // serializes form input
              success:function(response) {
                console.log(response);
                var hasil = response.success;
                Toast.fire({
                  icon: 'success',
                  title: hasil
                })
                tabelSJtambah(sj);
                $('#hapus-barang').hide();
                $('#btn-add-barang').show();
              }
            });
          });
        // /Hapus Barang
        $('#tmbsj').submit(function(e){
          e.preventDefault(); // prevent actual form submit
          var el = $('#btn-submit-sj');
          el.prop('disabled', true);
          setTimeout(function(){el.prop('disabled', false); }, 4000);
          var token = "<?php echo csrf_token(); ?>";
          var kode = $('#tmb-kode-sj').val();
          var today = new Date();
          var tgl = today.getDate();
          if(tgl == 1 || tgl == 2 || tgl == 3 || tgl == 4 || tgl == 5 || tgl == 6 || tgl == 7 || tgl == 8 || tgl == 9){
            tgl = '0'+tgl;
          }
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+tgl;
          var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
          var time = date+' '+time;
          $.ajax({
            type: 'post',
            url: '<?php echo url("data-sj"); ?>',
            data : {
              tipe        : $('#tmb-tipe-sj').val(),
              kode        : kode,
              tanggal     : $('#tmb-tgl-sj').val(),
              _token      : token,
              so          : $('#tmb-so-sj').val(),
              alamat      : $('#tmb-alamat-sj').val(),
              tgl_kirim   : $('#tmb-tglkirim-sj').val(),
              konsumen    : $('#tmb-konsumen-sj').val(), 
              kota        : $('#tmb-kota-sj').val(),
              nopol       : $('#tmb-nopol-sj').val(),
              ekspedisi   : $('#tmb-ekspedisi-sj').val(),
              resi        : $('#tmb-nokirim-so').val(),
              keterangan  : $('#tmb-keterangan-sj').val(),
              ketpakai    : $('#tmb-ketpakai-sj').val(),
              ketproduksi : $('#tmb-ketproduksi-sj').val(),
              time        : time,
              author      : "NPA.0002",
            }, // serializes form input
            success:function(response) {
              console.log(response);
              if(response.success == null){
                var hasil = response;
                Toast.fire({
                  icon: 'error',
                  title: hasil
                })
              } else {
                var hasil = response.success;
                Toast.fire({
                  icon: 'success',
                  title: hasil
                })
                $('#modal-tambah').modal('hide');
                var table = $('#tabel-sj').DataTable(); 
                table.ajax.reload( null, false );
              }
            }
          });
        });
      // Tambah SJ
      // Edit SJ
        $(document).on('click','.edit',function(){
          var kode = $(this).data('kode');
          $('#edt-kunci-sj').prop('checked',false);
          $('#edt-kode-sj').val(kode);
          $('#edt-btn-submit-sj').prop('disabled',true);
          $('#edt-tglkirim-sj').prop('disabled',false); $('#edt-kota-sj').prop('disabled',false); $('#edt-alamat-sj').prop('disabled',false); $('#edt-ekspedisi-sj').prop('disabled',false);
          $('#edt-tglditerima-sj').prop('disabled',false); $('#edt-nopol-sj').prop('disabled',false); $('#edt-alamat-sj').prop('disabled',false); $('#edt-nokirim,-sj').prop('disabled',false);$('#edt-keterangan-sj').prop('disabled',false);
          $('#edt-ketpakai-sj').prop('disabled',false);
          $('#edt-ketproduksi-sj').prop('disabled',false);
          $('#edt-btn-close-sj').prop('disabled',false);
          $('#edt-btn-submit-sj').prop('disabled',true);
          $('#btn-edit-x-sj').prop('disabled',false);
          $('#edt-btn-add-barang').hide();
          $('#edt-tambah-barang').hide();
          $('#edt-edit-barang').hide();
          $('#edt-hapus-barang').hide();
          $('#tbl_sj_edit').empty();
          $('#edt-so').hide();$('#edt-pakai').hide();$('#edt-produksi').hide();$('#edt-so1').hide();$('#edt-so2').hide();
          $.ajax({
            url :'<?php echo url("data-sj/'+kode+'/edit"); ?>',
            type : 'get',
            success : function(response){
              console.log(response);
              var tipe = kode.substr(7,2);
              if(tipe == 41 ){
                $('#edt-tipe-sj').val('PENJUALAN');
                $('#edt-so-sj').val(response.sj.so);
                $('#edt-namakonsumen-sj').val(response.sj.nama);
                $('#edt-tglkirim-sj').val(response.sj.tgl_kirim);
                $('#edt-tglditerima-sj').val(response.sj.tgl_diterima);
                $('#edt-kota-sj').val(response.sj.kota);
                $('#edt-nopol-sj').val(response.sj.nopol);
                $('#edt-alamat-sj').val(response.sj.alamat);
                $('#edt-ekspedisi-sj').val(response.sj.ekspedisi);
                $('#edt-nokirim-sj').val(response.sj.resi);
                $('#edt-keterangan-sj').val(response.sj.keterangan);
                $('#edt-so').show();$('#edt-so1').show();$('#edt-so2').show();
              } else if(tipe == 42){
                $('#edt-tipe-sj').val('PEMAKAIAN');
                $('#edt-ketpakai-sj').val(response.sj.keterangan);
                $('#edt-tglditerima-sj').val(response.sj.tgl_diterima);
                $('#edt-pakai').show();
              } else if(tipe == 43){
                $('#edt-tipe-sj').val('PRODUKSI');
                $('#edt-ketproduksi-sj').val(response.sj.keterangan);
                $('#edt-tglditerima-sj').val(response.sj.tgl_diterima);
                $('#edt-produksi').show();
              } else {
                $('#edt-tipe-sj').val('');
              }
              if(response.sj.status == 'Belum Diperiksa'){
                $('#edit-nama-pembuat').html(response.author.creator.nama);
                $('#edit-create-pembuat').html(response.author.created_at);
                $('#edit-nama-pemeriksa').html("-");
                $('#edit-create-pemeriksa').html("-");
              } else if(response.sj.status =='Sudah Diperiksa'){
                $('#edit-nama-pembuat').html(response.author.creator.nama);
                $('#edit-create-pembuat').html(response.author.created_at);
                $('#edit-nama-pemeriksa').html(response.author.pemeriksa.nama);
                $('#edit-create-pemeriksa').html(response.author.diperiksa);
              } 
            }
          });
        });
        $('#edt-kunci-sj').on('click',function(){
          var kode = $('#edt-kode-sj').val();
          var tipe = kode.substr(7,2);
          var checkBox = document.getElementById("edt-kunci-sj");
          var today = new Date();
          var tgl = today.getDate();
          if(tgl == 1 || tgl == 2 || tgl == 3 || tgl == 4 || tgl == 5 || tgl == 6 || tgl == 7 || tgl == 8 || tgl == 9){
            tgl = '0'+tgl;
          }
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+tgl;
          var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
          var time = date+' '+time;
          $('#edt-edit-time-sj').val(time);
          if(checkBox.checked == true){
            if (tipe == 41){
              $('#edt-tglkirim-sj').prop('disabled',true); $('#edt-kota-sj').prop('disabled',true); $('#edt-alamat-sj').prop('disabled',true); $('#edt-ekspedisi-sj').prop('disabled',true);
              $('#edt-tglditerima-sj').prop('disabled',true); $('#edt-nopol-sj').prop('disabled',true); $('#edt-alamat-sj').prop('disabled',true); $('#edt-nokirim,-sj').prop('disabled',true);$('#edt-keterangan-sj').prop('disabled',true);
            } else {
              $('#edt-ketpakai-sj').prop('disabled',true);
              $('#edt-ketproduksi-sj').prop('disabled',true);
              $('#edt-tglditerima-sj').prop('disabled',true);
            }
            $('#edt-btn-add-barang').show();
            $('#edt-btn-close-sj').prop('disabled',true);
            $('#edt-btn-submit-sj').prop('disabled',false);
            $('#btn-edit-x-sj').prop('disabled',true);
            tabelSJedit(kode);
          } else {
            if (tipe == 41){
              $('#edt-tglkirim-sj').prop('disabled',false); $('#edt-kota-sj').prop('disabled',false); $('#edt-alamat-sj').prop('disabled',false); $('#edt-ekspedisi-sj').prop('disabled',false);
              $('#edt-tglditerima-sj').prop('disabled',false); $('#edt-nopol-sj').prop('disabled',false); $('#edt-alamat-sj').prop('disabled',false); $('#edt-nokirim,-sj').prop('disabled',false);$('#edt-keterangan-sj').prop('disabled',false);
            } else {
              $('#edt-ketpakai-sj').prop('disabled',false);
              $('#edt-ketproduksi-sj').prop('disabled',false);
              $('#edt-tglditerima-sj').prop('disabled',false);
            }
            $('#edt-btn-add-barang').hide();
            $('#edt-tambah-barang').hide();
            $('#edt-edit-barang').hide();
            $('#edt-hapus-barang').hide();
            $('#edt-btn-close-sj').prop('disabled',false);
            $('#edt-btn-submit-sj').prop('disabled',true);
            $('#btn-edit-x-sj').prop('disabled',false);
            $('#tbl_sj_edit').empty();

            var today = new Date();
            var tgl = today.getDate();
            if(tgl == 1 || tgl == 2 || tgl == 3 || tgl == 4 || tgl == 5 || tgl == 6 || tgl == 7 || tgl == 8 || tgl == 9){
              tgl = '0'+tgl;
            }
            var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+tgl;
            var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
            var time = date+' '+time;
            var token = "<?php echo csrf_token(); ?>";
            $.ajax({
              type      : 'get',
              url       : '<?php echo url("hps-edt-detail-sj/'+kode+'"); ?>',
              data      : {
                _token    : token,
                start     : $('#edt-edit-time-sj').val(),
                end     : time,
              },
              success:function(response){
                console.log(response);
              }
            })
          }
        });
        //Tambah Barang
          $(document).on('click','#edt-btn-add-barang', function(){
            $('#edt-tambah-barang').show();
            $('#edt-btn-add-barang').hide();
            $('#edt-tambah-gudang-barang').empty();
            $('#edt-tambah-nama-barang').empty();
            $('#edt-tambah-gudang-barang').select2({
              placeholder: 'Pilih Gudang',
              ajax: {
                  url: '<?php echo url("dropdown-gudang"); ?>',
                  dataType: 'json',
                  processResults: function (data) {
                      return {
                          results: $.map(data, function (item) {
                              return {
                                  text: item.nama,
                                  id: item.kode
                              }
                          })
                      };
                  },
                  cache: true
              }
            });
            var so = $('#edt-so-sj') .val();
            $('#edt-tambah-nama-barang').select2({
              placeholder: 'Pilih Barang',
              ajax: {
                  url: '<?php echo url("dropdown-barangso/'+so+'"); ?>',
                  dataType: 'json',
                  processResults: function (data) {
                      return {
                          results: $.map(data, function (item) {
                              return {
                                  text: item.nama,
                                  id: item.kode
                              }
                          })
                      };
                  },
                  cache: true
              }
            });
            
          });
          $(document).on('change','#edt-tambah-gudang-barang', function(){
            var gudang = $(this).val();
            $('#edt-tambah-nama-barang').empty();
            $('#edt-tambah-nama-barang').select2({
              placeholder: 'Pilih Barang',
              ajax: {
                  url: '<?php echo url("dropdown-barangmr/'+gudang+'"); ?>',
                  dataType: 'json',
                  processResults: function (data) {
                      return {
                          results: $.map(data, function (item) {
                              return {
                                  text: item.nama,
                                  id: item.kode
                              }
                          })
                      };
                  },
                  cache: true
              }
            });
          });
          $('#edt-tambah-nama-barang').on('change', function (){
            var barang = $(this).val();
            //SATUAN
            $.ajax({
              url :'<?php echo url("data-barang/'+barang+'/edit"); ?>',
              type : 'get',
              success : function(response){
                console.log(response);
                $('#edt-tambah-satuan-barang').val(response.result.satuan);
              }
            });
            //STOK
            $.ajax({
              url :'<?php echo url("stock-barangmr/'+barang+'"); ?>',
              type : 'get',
              data :{
                gudang : $('#edt-tambah-gudang-barang').val(),
              },
              success : function(response){
                console.log(response);
                if (response == null){
                  $('#edt-tambah-stock-barang').val(0);
                  $('#edt-tambah-qty-barang').prop('max',0);
                } else {
                  $('#edt-tambah-stock-barang').val(response);
                  $('#edt-tambah-qty-barang').prop('max',response);
                }
              }
            });
          });
          $('#edt-form-tambah-barang').submit(function(e){
            var qty = $('#edt-tambah-qty-barang').val();
            var stock = $('#edt-tambah-stock-barang').val();
            e.preventDefault(); // prevent actual form submit
            var el = $('#edt-btn-tambah-barang');
            el.prop('disabled', true);
            setTimeout(function(){el.prop('disabled', false); }, 4000);
            var token = "<?php echo csrf_token(); ?>";
            var sj = $('#edt-kode-sj').val();
            var today = new Date();
            var tgl = today.getDate();
            if(tgl == 1 || tgl == 2 || tgl == 3 || tgl == 4 || tgl == 5 || tgl == 6 || tgl == 7 || tgl == 8 || tgl == 9){
              tgl = '0'+tgl;
            }
            var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+tgl;
            var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
            var time = date+' '+time;
            $.ajax({
              type: 'post',
              url: '<?php echo url("data-detailsj"); ?>',
              data : {
                sj          : sj,
                barang      : $('#edt-tambah-nama-barang').val(),
                nama        : $('#edt-tambah-namareq-barang').val(),
                _token      : token,
                gudang      : $('#edt-tambah-gudang-barang').val(),
                stock       : stock,
                qty         : $('#edt-tambah-qty-barang').val(),
                keterangan  : $('#edt-tambah-keterangan-barang').val(),
                time        : time
              }, // serializes form input
              success:function(response) {
                console.log(response);
                if(response.error == ''){
                  var hasil = response.success;
                  Toast.fire({
                    icon: 'success',
                    title: hasil
                  })
                  tabelSJedit(sj);
                  document.getElementById("edt-form-tambah-barang").reset();
                  $('#edt-tambah-barang').hide();
                  $('#edt-btn-add-barang').show();
                } else {
                  Toast.fire({
                    icon: 'error',
                    title: response.error
                  })
                }
                
              }
            });
            
            
          });
        //Tambah Barang
        //Edit Barang
          $(document).on('click','.edtbarang',function(){
            $('#edt-edit-barang').show();
            $('#edt-tambah-barang').hide();
            $('#edt-hapus-barang').hide();
            $('#edt-btn-add-barang').hide();
            var kode = $(this).data('kode');
            console.log(kode);
            $.ajax({
              url :'<?php echo url("data-detailsj/'+kode+'/edit"); ?>',
              type : 'get',
              success : function(response){
                console.log(response);
                $('#edt-edit-kode-barang').val(kode);
                $('#edt-edit-gudang-barang').val(response.gudang);
                $('#edt-edit-nama-barang').val(response.nama);
                $('#edt-edit-namareq-barang').val(response.nama_request),
                $('#edt-edit-qty-barang').val(response.qty);
                $('#edt-edit-stock-barang').val(response.stock);
                $('#edt-edit-satuan-barang').val(response.satuan);
                $('#edt-edit-keterangan-barang').val(response.keterangan);
              }
            });
          });
          $('#edt-btn-cancel-edit-barang').on('click',function(){
            $('#edt-edit-barang').hide();
            $('#edt-btn-add-barang').show();
          });
          $('#edt-edit-tambah-barang').submit(function(e){
            e.preventDefault(); // prevent actual form submit
            var el = $('#edt-btn-edit-barang');
            el.prop('disabled', true);
            setTimeout(function(){el.prop('disabled', false); }, 4000);
            var token = "<?php echo csrf_token(); ?>";
            var kode = $('#edt-edit-kode-barang').val();
            var sj = $('#edt-kode-sj').val();
            $.ajax({
              type: 'put',
              url: '<?php echo url("data-detailsj/'+kode+'"); ?>',
              data : {
                kode        : kode,
                _token      : token,
                nama        : $('#edt-edit-namareq-barang').val(),
                qty         : $('#edt-edit-qty-barang').val(),
                keterangan  : $('#edt-edit-keterangan-barang').val(),
              }, // serializes form input
              success:function(response) {
                console.log(response);
                var hasil = response.success;
                Toast.fire({
                  icon: 'success',
                  title: hasil
                })
                tabelSJedit(sj);
                document.getElementById("edt-edit-tambah-barang").reset();
                $('#edt-edit-barang').hide();
                $('#edt-btn-add-barang').show();
              }
            });
          });
        //Edit Barang
        //Hapus Barang
          $(document).on('click','.hpsbarang', function(){
            $('#edt-hapus-barang').show();
            $('#edt-edit-barang').hide();
            $('#edt-tambah-barang').hide();
            $('#edt-btn-add-barang').hide();
            var kode = $(this).data('kode');
            $.ajax({
              url :'<?php echo url("data-detailsj/'+kode+'/edit"); ?>',
              type : 'get',
              success : function(response){
                console.log(response);
                $('#edt-hapus-kode-barang').val(kode);
                $('#edt-hapus-nama-barang').html(response.nama);
              }
            });
          });
          $(document).on('click','#edt-btn-cancel-hapus',function(){
            $('#edt-hapus-barang').hide();
            $('#edt-btn-add-barang').show();
          });
          $('#edt-form-hapus-barang').submit(function(e){
            e.preventDefault(); // prevent actual form submit
            var el = $('#edt-btn-hapus-barang');
            el.prop('disabled', true);
            setTimeout(function(){el.prop('disabled', false); }, 4000);
            var token = "<?php echo csrf_token(); ?>";
            var kode = $('#edt-hapus-kode-barang').val();
            var sj = $('#edt-kode-sj').val();
            $.ajax({
              type: 'delete',
              url: '<?php echo url("data-detailsj/'+kode+'"); ?>',
              data : {
                kode        : kode,
                _token      : token,
              }, // serializes form input
              success:function(response) {
                console.log(response);
                var hasil = response.success;
                Toast.fire({
                  icon: 'success',
                  title: hasil
                })
                tabelSJedit(sj);
                $('#edt-hapus-barang').hide();
                $('#edt-btn-add-barang').show();
              }
            });
          });
        //Hapus Barang
        $('#edtsj').submit(function(e){
          var kode  = $('#edt-kode-sj').val();
          
          e.preventDefault(); // prevent actual form submit
          var el = $('#edt-btn-submit-sj');
          el.prop('disabled', true);
          setTimeout(function(){el.prop('disabled', false); }, 4000);
          var token = "<?php echo csrf_token(); ?>";
          var today = new Date();
          var tgl = today.getDate();
          if(tgl == 1 || tgl == 2 || tgl == 3 || tgl == 4 || tgl == 5 || tgl == 6 || tgl == 7 || tgl == 8 || tgl == 9){
            tgl = '0'+tgl;
          }
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+tgl;
          var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
          var time = date+' '+time;
          $.ajax({
            type: 'put',
            url: '<?php echo url("data-sj/'+kode+'"); ?>',
            data : {
              tipe        : $('#edt-tipe-sj').val(),
              kode        : kode,
              tanggal     : $('#edt-tgl-sj').val(),
              _token      : token,
              so          : $('#edt-so-sj').val(),
              tgl_kirim   : $('#edt-tglkirim-sj').val(),
              tgl_terima  : $('#edt-tglditerima-sj').val(),
              konsumen    : $('#edt-konsumen-sj').val(), 
              kota        : $('#edt-kota-sj').val(),
              nopol       : $('#edt-nopol-sj').val(),
              ekspedisi   : $('#edt-ekspedisi-sj').val(),
              resi        : $('#edt-nokirim-so').val(),
              keterangan  : $('#edt-keterangan-sj').val(),
              ketpakai    : $('#edt-ketpakai-sj').val(),
              ketproduksi : $('#edt-ketproduksi-sj').val(),
              time        : time,
            }, // serializes form input
            success:function(response) {
              console.log(response);
              var hasil = response.success;
              Toast.fire({
                icon: 'success',
                title: hasil
              })
              $('#modal-edit').modal('hide');
              var table = $('#tabel-sj').DataTable(); 
              table.ajax.reload( null, false );
            }
          });
        });
      // Edit SJ
      // Detail SJ
        $(document).on('click','.detail',function(){
          $('#detail-so').hide();$('#detail-so1').hide();$('#detail-so2').hide();
          $('#detail-pakai').hide(); $('#detail-produksi').hide();
          var kode = $(this).data('kode');
         
          $.ajax({
            url :'<?php echo url("data-sj/'+kode+'/edit"); ?>',
            type : 'get',
            success : function(response){
              console.log(response);
              $('#detail-tgl-sj').val(response.sj.tanggal);
              $('#detail-kode-sj').val(kode);
              var tipe = kode.substr(7,2);
              if(tipe == 41 ){
                $('#detail-tipe-sj').val('PENJUALAN');
                $('#detail-so-sj').val(response.sj.so);
                $('#detail-namakonsumen-sj').val(response.sj.nama);
                $('#detail-tglkirim-sj').val(response.sj.tgl_kirim);
                $('#detail-kota-sj').val(response.sj.kota);
                $('#detail-nopol-sj').val(response.sj.nopol);
                $('#detail-alamat-sj').val(response.sj.alamat);
                $('#detail-ekspedisi-sj').val(response.sj.ekspedisi);
                $('#detail-nokirim-sj').val(response.sj.resi);
                $('#detail-keterangan-sj').val(response.sj.keterangan);
                $('#detail-so').show();$('#detail-so1').show();$('#detail-so2').show();
              } else if(tipe == 42){
                $('#detail-tipe-sj').val('PEMAKAIAN');
                $('#detail-ketpakai-sj').val(response.sj.keterangan);
                $('#detail-pakai').show();
              } else if(tipe == 43){
                $('#detail-tipe-sj').val('PRODUKSI');
                $('#detail-ketproduksi-sj').val(response.sj.keterangan);
                $('#detail-produksi').show();
              } else {
                $('#detail-tipe-sj').val('');
              }
              if(response.sj.status == 'Belum Diperiksa'){
                $('#detail-nama-pembuat').html(response.author.creator.nama);
                $('#detail-create-pembuat').html(response.author.created_at);
                $('#detail-nama-pemeriksa').html("-");
                $('#detail-create-pemeriksa').html("-");
                $('#btn-detail-submit-sj').show();
              } else if(response.sj.status =='Sudah Diperiksa'){
                $('#detail-nama-pembuat').html(response.author.creator.nama);
                $('#detail-create-pembuat').html(response.author.created_at);
                $('#detail-nama-pemeriksa').html(response.author.pemeriksa.nama);
                $('#detail-create-pemeriksa').html(response.author.diperiksa);
                $('#btn-detail-submit-sj').hide();
              } 
              tabelSJdetail(kode);
            }
          });
        });
        $('#dtlsj').submit(function(e){
          e.preventDefault(); // prevent actual form submit
          var el = $('#btn-detail-submit-sj');
          el.prop('disabled', true);
          setTimeout(function(){el.prop('disabled', false); }, 4000);
          var token = "<?php echo csrf_token(); ?>";
          var kode = $('#detail-kode-sj').val();
          var today = new Date();
          var tgl = today.getDate();
          if(tgl == 1 || tgl == 2 || tgl == 3 || tgl == 4 || tgl == 5 || tgl == 6 || tgl == 7 || tgl == 8 || tgl == 9){
            tgl = '0'+tgl;
          }
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+tgl;
          var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
          var time = date+' '+time;
          $.ajax({
            type: 'put',
            url: '<?php echo url("data-author/'+kode+'"); ?>',
            data : {
              kode        : kode,
              _token      : token,
              konfirmator : 'NPA.0003',
              time        : time,
              type        : "sj",
            }, // serializes form input
            success:function(response) {
              console.log(response);
              var hasil = response.success;
              Toast.fire({
                icon: 'success',
                title: hasil
              })
              $('#modal-detail').modal('hide');
              var table = $('#tabel-sj').DataTable(); 
              table.ajax.reload( null, false );
            }
          });
        });
        $('#cetak-sj').on('click',function(){
          var kode = $('#detail-kode-sj').val();
          var tipe = kode.substr(7,2);
          if(tipe == 41){
            $.ajax({
              type    : 'get',
              url     : '<?php echo url("cekinvoice-sj/'+kode+'"); ?>',
              success : function(response){
                console.log(response);
                if(response == [null]){
                  Toast.fire({
                    icon: 'error',
                    title: 'Invoice Belum Dibuat'
                  })
                } else {
                  location.href = 'cetak-sj?kode='+kode;
                }
                
              }
            });
          } else {

          }

        });
      // Detail SJ

      // Hapus SJ
        $(document).on('click','.hapus',function(){
          var kode = $(this).data('kode');
          $('#hapus-kode-sj').val(kode);
          $('#hapus-kode').html(kode);
        });
        $('#form-hapus-sj').submit(function(e){
          e.preventDefault(); // prevent actual form submit
          var token = "<?php echo csrf_token(); ?>";
          var kode =  $('#hapus-kode-sj').val();
          $.ajax({
            type    : 'delete',
            url     : '<?php echo url("data-sj/'+kode+'"); ?>',
            data    : {
              _token  : token,
            },
            success:function(response) {
              console.log(response);
              var hasil = response.success;
              Toast.fire({
                icon: 'success',
                title: hasil
              })
              $('#modal-hapus').modal('hide');
              var table = $('#tabel-sj').DataTable(); 
              table.ajax.reload( null, false );
            },
            error:function(response){

            }
          });
        });
      // Hapus SJ

      function tabelSJtambah(kode){
        $.ajax({
          url :'<?php echo url("data-detailsj/'+kode+'"); ?>',
          type : 'get',
          success : function(response){
            console.log(response);
            $('#tbl_sj_tambah').empty();
            var datahandler = $('#tbl_sj_tambah');
            var n= 0;
            var sum = 0;
            $.each(response, function(key,val){
                var Nrow = $("<tr>");
                  var nomor = n+1;
                Nrow.html("<td><button type='button' class='btn btn-default'>Action</button><button type='button' class='btn btn-default dropdown-toggle dropdown-icon' data-toggle='dropdown'><span class='sr-only'>Toggle Dropdown</span></button><div class='dropdown-menu' role='menu'><a class='dropdown-item editbarang' style='color:orange' data-kode='"+response[n]['kode']+"'><b>Edit</b></a><a class='dropdown-item hapusbarang' style='color:red' data-kode='"+response[n]['kode']+"'><b>Hapus</b></a></div></td><td>"+nomor+"</td><td>"+response[n]['kode_gdg']+"</td><td>"+response[n]['gudang']+"</td><td>"+response[n]['kode_brg']+"</td><td>"+response[n]['nama']+"</td><td>"+response[n]['nama_request']+"</td><td>"+response[n]['satuan']+"</td><td>"+response[n]['qty']+"</td><td>"+response[n]['keterangan']+"</td><td></td><td></td><td></td><td></td></tr>");
                datahandler.append(Nrow);
                n = n+1;
            });
            
          }
        });
      }
      function tabelSJedit(kode){
        $.ajax({
          url :'<?php echo url("data-detailsj/'+kode+'"); ?>',
          type : 'get',
          success : function(response){
            console.log(response);
            $('#tbl_sj_edit').empty();
            var datahandler = $('#tbl_sj_edit');
            var n= 0;
            var sum = 0;
            $.each(response, function(key,val){
                var Nrow = $("<tr>");
                  var nomor = n+1;
                Nrow.html("<td><button type='button' class='btn btn-default'>Action</button><button type='button' class='btn btn-default dropdown-toggle dropdown-icon' data-toggle='dropdown'><span class='sr-only'>Toggle Dropdown</span></button><div class='dropdown-menu' role='menu'><a class='dropdown-item edtbarang' style='color:orange' data-kode='"+response[n]['kode']+"'><b>Edit</b></a><a class='dropdown-item hpsbarang' style='color:red' data-kode='"+response[n]['kode']+"'><b>Hapus</b></a></div></td><td>"+response[n]['kode_gdg']+"</td><td>"+response[n]['gudang']+"</td><td>"+response[n]['kode_brg']+"</td><td>"+response[n]['nama']+"</td><td>"+response[n]['nama_request']+"</td><td>"+response[n]['satuan']+"</td><td>"+response[n]['qty']+"</td><td>"+response[n]['keterangan']+"</td><td></td><td></td><td></td><td></td></tr>");
                datahandler.append(Nrow);
                n = n+1;
            });
            
          }
        });
      }
      function tabelSJdetail(kode){
        $.ajax({
          url :'<?php echo url("data-detailsj/'+kode+'"); ?>',
          type : 'get',
          success : function(response){
            console.log(response);
            $('#tbl_sj_detail').empty();
            var datahandler = $('#tbl_sj_detail');
            var n= 0;
            var sum = 0;
            $.each(response, function(key,val){
                var Nrow = $("<tr>");
                  var nomor = n+1;
                Nrow.html("<td>"+nomor+"</td><td>"+response[n]['kode_gdg']+"</td><td>"+response[n]['gudang']+"</td><td>"+response[n]['kode_brg']+"</td><td>"+response[n]['nama']+"</td><td>"+response[n]['nama_request']+"</td><td>"+response[n]['satuan']+"</td><td>"+response[n]['qty']+"</td><td>"+response[n]['keterangan']+"</td><td></td><td></td><td></td><td></td></tr>");
                datahandler.append(Nrow);
                n = n+1;
            });
            
          }
        });
      }

      function formatRupiah(money) {
        return new Intl.NumberFormat('id-ID',
          { style: 'currency', currency: 'IDR' }
        ).format(money);
      }
      var Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 4000
      });

    

    </script>
  </body>
</html>
<?php /**PATH I:\Laravel\NPA\resources\views/S-Admin/surat-jalan.blade.php ENDPATH**/ ?>