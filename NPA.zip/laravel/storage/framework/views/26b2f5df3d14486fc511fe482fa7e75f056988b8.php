<!-- jQuery -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Ajax-->

<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/chart.js/Chart.min.js"></script>

<!-- JQVMap -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/jqvmap/jquery.vmap.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/moment/moment.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('AdminLTE/dist')); ?>/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo e(asset('AdminLTE/dist')); ?>/js/pages/dashboard.js"></script>
<script>
  // var Toast = Swal.mixin({
  //   toast: true,
  //   position: 'top-center',
  //   showConfirmButton: false,
  //   timer: 3000
  // });
</script><?php /**PATH I:\Laravel\NPA\resources\views/layout/script.blade.php ENDPATH**/ ?>