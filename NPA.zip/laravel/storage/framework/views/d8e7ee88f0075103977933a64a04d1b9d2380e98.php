<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        
        <a class="nav-link">
          <?php echo $__env->make('layout/tanggal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
        </a>
      </li>
      
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="material-icons">settings</i>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header">Pengaturan</span>
          <div class="dropdown-divider"></div>
          <a data-toggle="modal" id="ubah-password" data-target="#modal-ubah-password"class="dropdown-item">
            <i class="fas fa-key mr-2"></i> Ubah Password
          </a>
          <div class="dropdown-divider"></div>
          <a href="<?php echo e(url ('logout')); ?>" class="dropdown-item">
            <i class="fas fa-sign-out-alt"></i> Keluar
          </a>
          
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      
    </ul>
  </nav>

  <div class="modal fade" id="modal-ubah-password">
    <div class="modal-dialog modal-sm">
        <form id="fm-ubahpassword">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h4 class="modal-title">Ubah Password</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="form-group">
                        <label>Tuliskan Password Lama </label>
                        <input id="pwd_lama"  class="form-control" type="password" minlength="6" required>
                        <label>Buat Password Baru </label>
                        <input id="pwd_baru"  class="form-control" type="password" minlength="6" required>
                        <label>Tulis Ulang Password baru </label>
                        <input id="repwd_baru"  class="form-control" type="password" minlength="6" required>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="modal-footer justify-content-between ">
                    <button type="button" class="col-sm-4 btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="col-sm-4 form-control btn btn-warning">Ubah</button>
                </div>
            </div>
        </form>
    </div>
</div>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/sweetalert2/sweetalert2.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/jquery-ui/jquery-ui.min.js"></script>
<script>
  
  $('#ubah-password').on('click', function(){
    var pasword = "<?php echo e($user->password); ?>";
    console.log(pasword);
  });
  $('#fm-ubahpassword').submit(function(e){
    e.preventDefault(); // prevent actual form submit
    var el = $('.btn-warning');
    el.prop('disabled', true);
    setTimeout(function(){el.prop('disabled', false); }, 3000);
    var token = "<?php echo csrf_token(); ?>";
    var id = "<?php echo e($user->id); ?>";
    var pwd = $('#pwd_baru').val();
    var repwd = $('#repwd_baru').val();
    
    if(repwd == pwd){

    } else {
      Toast.fire({
        icon: 'error',
        title: 'Password baru tidak sama'
      })
      return false;
    }
    console.log(id);
    $.ajax({
      type: 'post',
      url: '<?php echo url("ubah-password"); ?>',
      data : {
        pwd    : $('#pwd_baru').val(),
        pwdlama : $('#pwd_lama').val(),
        _token : token,
        },
      success:function(response){
          console.log(response);
          if(response.success != true){
            Toast.fire({
              icon: 'error',
              title: response.pesan
            })
          } else {
            Toast.fire({
              icon: 'success',
              title: response.pesan
            })
          }
      }, // serializes form input
    });
  });
</script>
  <!-- /.navbar --><?php /**PATH I:\Laravel\NPA\resources\views/layout/navbar.blade.php ENDPATH**/ ?>