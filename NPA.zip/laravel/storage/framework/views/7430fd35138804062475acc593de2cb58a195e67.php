<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('layout/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-responsive/css/responsive.bootstrap4.min.css">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/select2/css/select2.min.css">
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<!-- SweetAlert -->
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">

<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="<?php echo e(asset('img')); ?>/logo.png" alt="AdminLTELogo" height="60" width="60">
    
    <h4><b> Nusa Pratama Anugerah </b></h4>
  </div> 
  <!-- /.navbar -->
  <?php echo $__env->make('layout/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('layout/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Bank</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard">Home</a></li>
              <li class="breadcrumb-item active">Data Bank</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                  <button type="button" id="tambahdata" data-toggle="modal" data-target="#modal-tmb-bank"class="btn bg-gradient-primary">Tambah Bank</button>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive">
                <table id="tabel-bank" class="table  table-striped">
                  <thead>
                  <tr>
                    <th class="col-lg-2">Action</th>
                    <th class="col-lg-1">Bank</th>
                    <th class="col-lg-2">No. Rekening</th>
                    <th class="col-lg-5">Atas Nama</th>
                  </tr>
                  </thead>
                  <tbody>
                  
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<!-- MODAL -->
  <!-- MODAL Tambah Bank -->
    <div class="modal fade" id="modal-tmb-bank">
      <div class="modal-dialog modal-sm">
          <div class="modal-content">
              <form id="tmbbank">
                  <div class="modal-header bg-primary">
                      <h4 class="modal-title">Tambah Data Bank</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <b><span aria-hidden="true">&times;</span></b>
                      </button>
                  </div>
                  <div class="modal-body">
                        <div class="form-group">
                          <label>Bank</label>
                          <input id="tmb-bank" class="form-control" type="text" required>
                          <label>No Rekening </label>
                          <input id="tmb-rekening" class="form-control" type="text" onkeypress="return angka('evt')" maxlength="16" required>
                          <label>Atas nama</label>
                          <input id="tmb-AN" type="text" class="form-control" required>
                          
                        </div>
                  </div>
                  <div class="modal-footer justify-content-between ">
                      <button type="button" class=" col-sm-4 btn btn-default" data-dismiss="modal">Close</button>
                      <button type="submit" id="btn-tambah" class=" col-sm-4 form-control btn btn-primary">Tambah</button>
                  </div>
              </form>
          </div>
      </div>
    </div>
  <!--/ Modal Tambah Bank -->
  <!-- Modal Detail Bank -->
    <div class="modal fade" id="modal-detail">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
              <div class="modal-header bg-info">
                  <h4 class="modal-title">Detail Data Bank</h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                  </button>
              </div>
              <div class="modal-body">
                    <div class="form-group">
                        <label>Bank</label>
                        <input id="dtl-bank" class="form-control" type="text" readonly>
                        <label>No. Rekening </label>
                        <input id="dtl-rekening" class="form-control" onkeypress="return angka('evt')" maxlength="16" type="text" readonly>
                        <label>Atas Nama</label>
                        <input id="dtl-AN" type="text" class="form-control" required readonly>
                        <label>Tanggal Dibuat</label>
                        <input type="date" id="dtl-created" class="form-control"  disabled>
                    </div>
              </div>
              <div class="modal-footer justify-content-between ">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </div>
        </div>
    </div>
  <!-- /Modal Detail Bank -->
  <!-- MODAL Edit Bank -->
    <div class="modal fade" id="modal-edit">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <form id="edtbank">
                    <div class="modal-header bg-warning">
                        <h4 class="modal-title">Edit Data Bank</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                          <div class="form-group">
                            <input id="edt-kode" type="text" hidden>
                            <label>Bank</label>
                            <input id="edt-bank" class="form-control" type="text" required readonly>
                            <label>No. Rekening </label>
                            <input id="edt-rekening" class="form-control" type="text" onkeypress="return angka('evt')" required>
                            <label>Atas Nama</label>
                            <input id="edt-AN" type="text" class="form-control" required >
                          </div>
                    </div>
                    <div class="modal-footer justify-content-between ">
                        <button type="button" class="col-sm-4 btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" id="btn-edit" class=" col-sm-4 form-control btn btn-warning">Edit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
  <!--/ Modal Edit Bank -->
  <!-- MODAL Hapus Bank -->
    <div class="modal fade" id="modal-hapus">
        <div class="modal-dialog modal-sm">
            <form id="hpsbank">
                <div class="modal-content">
                    <div class="modal-header bg-danger">
                        <h4 class="modal-title">Hapus Data Bank</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                      <div class="form-group">
                          Apakah Anda Yakin Akan Menghapus Data ini ?
                          <div class="row">
                              <input id="hps-kode" class="form-control" type="text" required hidden>
                              <label class=" col-md-3">Rekening </label> 
                              <label class="col-md-1">:</label>
                              <label class="col-md-8" id="hps-bank" > 	</label>
                          </div>
                          <div class="row">
                              <label class=" col-md-3">Nama </label> 
                              <label class="col-md-1">:</label>
                              <label class="col-md-8"id="hps-AN" ></label>
                          </div>
                      </div>
                    </div>
                    <div class="modal-footer justify-content-between ">
                        <button type="button" class="col-sm-4 btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" id="btn-hapus" class=" col-sm-4 form-control btn btn-danger">Hapus</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
  <!--/ Modal Hapus Bank -->
<!--/ MODAL -->

  <?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.colVis.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/sweetalert2/sweetalert2.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('AdminLTE/dist')); ?>/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<!-- Page specific script -->
<script>
  $(document).ready(function() {   
    $('#tabel-bank').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"],
        processing: true,
        serverSide: true,
        ajax: '<?php echo url("data-bank"); ?>',
        columns: [         
            
            { data: 'action', name: 'action',orderable:false, searchable:false},
            { data: 'bank', name: 'bank',orderable:true},
            { data: 'rekening', name: 'rekening',orderable:true},
            { data: 'atas_nama', name: 'atas_nama',orderable:true},
            
        ]
    });
  }); 
  $.ajaxSetup({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });

  var Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 5000
  });
  $(document).on('click','#tambahdata',function(){
    document.getElementById("tmbbank").reset();
  });
  $('#tmbbank').submit(function(e){
    e.preventDefault(); // prevent actual form submit
    var el = $('#btn-tambah');
    el.prop('readonly', true);
    setTimeout(function(){el.prop('readonly', false); }, 3000);
    var token = "<?php echo csrf_token(); ?>";
    var today = new Date();
    var tgl = today.getDate();
    if(tgl == 1 || tgl == 2 || tgl == 3 || tgl == 4 || tgl == 5 || tgl == 6 || tgl == 7 || tgl == 8 || tgl == 9){
        tgl = '0'+tgl;
    }
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+tgl;
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var time = date+' '+time;
    $.ajax({
      type: 'post',
      url: '<?php echo url("data-bank"); ?>',
      data : {
        bank     : $('#tmb-bank').val(),
        _token   : token,
        rekening : $('#tmb-rekening').val(),
        an       : $('#tmb-AN').val(),
        time     : time, 
      }, // serializes form input
      success:function(response) {
        var hasil = response.success;
        Toast.fire({
          icon: 'success',
          title: hasil
        })
        $('#modal-tmb-bank').modal('hide');
        var table = $('#tabel-bank').DataTable(); 
        table.ajax.reload( null, false );
      }
    });
  });
  $('#edtbank').submit(function(e){
    e.preventDefault(); // prevent actual form submit
    var el = $('#btn-edit');
    el.prop('readonly', true);
    setTimeout(function(){el.prop('readonly', false); }, 3000);
    var token = "<?php echo csrf_token(); ?>";
    var kode = $('#edt-kode').val();
    var today = new Date();
    var tgl = today.getDate();
    if(tgl == 1 || tgl == 2 || tgl == 3 || tgl == 4 || tgl == 5 || tgl == 6 || tgl == 7 || tgl == 8 || tgl == 9){
        tgl = '0'+tgl;
    }
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+tgl;
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var time = date+' '+time;
    $.ajax({
      type: 'PUT',
      url: '<?php echo url("data-bank/'+kode+'"); ?>',
      data : {
        bank     : $('#edt-bank').val(),
        _token   : token,
        rekening : $('#edt-rekening').val(),
        an       : $('#edt-AN').val(),
        time     : time,
      }, // serializes form input
      success:function(response) {
        console.log(response);
        var hasil = response.success;
        Toast.fire({
          icon: 'success',
          title: hasil
        })
        $('#modal-edit').modal('hide');
        var table = $('#tabel-bank').DataTable(); 
        table.ajax.reload( null, false );
      },
      error:function(response){

      }
    });
  });
  $('#hpsbank').submit(function(e){
    e.preventDefault(); // prevent actual form submit
    var el = $('#btn-hapus');
    el.prop('readonly', true);
    setTimeout(function(){el.prop('readonly', false); }, 3000);
    var token = "<?php echo csrf_token(); ?>";
    var kode = $('#hps-kode').val();
    $.ajax({
      type    : 'delete',
      url     : '<?php echo url("data-bank/'+kode+'"); ?>',
      data    : {
        _token  : token,
      },
      success:function(response) {
        console.log(response);
        var hasil = response.success;
        Toast.fire({
          icon: 'success',
          title: hasil
        })
        $('#modal-hapus').modal('hide');
        var table = $('#tabel-bank').DataTable(); 
        table.ajax.reload( null, false );
      },
      error:function(response){

      }
    });
  });
  $('body').on('click', '.detail', function () {
      var kode = $(this).data('kode');
      $.ajax({
        url :'<?php echo url("data-bank/'+kode+'/edit"); ?>',
        type : 'get',
        success : function(response){
          $('#dtl-bank').val(response.result.bank);
          $('#dtl-rekening').val(response.result.rekening);
          $('#dtl-AN').val(response.result.atas_nama);
          $('#dtl-created').val(response.result.created_at);
          
        }
      });
  });
  $('body').on('click', '.edit', function () {
    var kode = $(this).data('kode');
    document.getElementById("edtbank").reset();
    $.ajax({
      url :'<?php echo url("data-bank/'+kode+'/edit"); ?>',
      type : 'get',
      success : function(response){
        $('#edt-bank').val(response.result.bank);
        $('#edt-rekening').val(response.result.rekening);
        $('#edt-AN').val(response.result.atas_nama);
        $('#edt-kode').val(kode);
      }
    });
  });
  $('body').on('click', '.hapus', function () {
      document.getElementById("hpsbank").reset();
      var rekening = $(this).data('rekening');
      var bank = $(this).data('bank');
      var AN = $(this).data('nama');
      var kode = $(this).data('kode');
      console.log(kode);
      document.getElementById("hps-bank").innerHTML = bank+" "+rekening;
      document.getElementById("hps-AN").innerHTML = AN ;
      $('#hps-kode').val(kode);
  });
  function angka(evt){
      var charCode = (evt.which) ? evt.which : event.keyCode
      if (charCode > 31 && (charCode < 48 || charCode > 57))

          return false;
      return true;
  } 
</script>
</body>
</html>
<?php /**PATH I:\Laravel\NPA\resources\views/S-Admin/data-bank.blade.php ENDPATH**/ ?>