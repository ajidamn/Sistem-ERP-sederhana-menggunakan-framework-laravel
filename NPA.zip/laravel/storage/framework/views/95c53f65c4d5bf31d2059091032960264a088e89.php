<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layout/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/css/buttons.bootstrap4.min.css">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/select2/css/select2.min.css">
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="<?php echo e(asset('img')); ?>/logo.png" alt="AdminLTELogo" height="60" width="60">
    
    <h4><b> Nusa Pratama Anugerah </b></h4>
  </div> 
  <?php echo $__env->make('layout/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('layout/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Data Customer</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item "><a href="dashboard">Home</a></li>
              <li class="breadcrumb-item active">Data Customer</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <button type="button" id="tambahdata" data-toggle="modal" data-target="#modal-tambah-customer"class="btn bg-gradient-primary">Tambah Customer</button>
                </div>
                <!-- /.card-header -->
                <div class="card-body table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                      <th>Action</th>
                      <th>No.</th>
                      <th>ID Customer</th>
                      <th>Nama Customer</th>
                      <th>Nama Perusahaan</th>
                      <th>Nomor Telp WA</th>
                      
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                      <td>
                        <button type="button" class="btn btn-default">Action</button>
                        <button type="button" class="btn btn-default dropdown-toggle dropdown-icon" data-toggle="dropdown">
                          <span class="sr-only">Toggle Dropdown</span>
                        </button>
                        <div class="dropdown-menu" role="menu">
                          <a class="dropdown-item" style="color:green;" data-toggle="modal" data-target="#modal-knfm-po"><b>Konfirmasi</b></a>
                          <a class="dropdown-item" style="color:lightblue;" data-toggle="modal" data-target="#modal-dtl-po"><b>Detail</b></a>
                          <a class="dropdown-item" style="color:orange" data-toggle="modal" data-target="#modal-edt-po"><b>Edit</b></a>
                          <a class="dropdown-item" style="color:red" data-toggle="modal" data-target="#modal-hps-po"><b>Hapus</b></a>
                        </div>
                      </td>
                      <td>1.</td>
                      <td>NP-C-00000357</td>
                      <td>ABDUL ROHMAN AL ABDI</td>
                      <td>PT. Rakyat Sejahtera</td>
                      <td>0866512322</td>
                      
                    </tr>
                    </tbody>
                    
                  </table>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
      </section>
    <!-- /.content -->
  </div>
  <!-- MODAL -->
  <!-- MODAL Tambah Customer -->
  <div class="modal fade" id="modal-tambah-customer">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="tambahcustomer">
                <div class="modal-header bg-primary">
                    <h4 class="modal-title">Tambah Data Customer</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                        <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label>ID Customer</label>
                                <input id="tambah_id_customer "name="tambah_id_customer"class="form-control" type="text" disabled="" >
                                <label>Nama Customer </label>
                                <input id="tambah_nama_customer" name="tambah_nama_customer" class="form-control" type="text" required>
                                <label>Nomor Customer (WA)</label>
                                <input id="tambah_cp_customer" name="tambah_cp_customer" class="form-control" type="text" onkeypress="return angka('evt')" maxlength="12" required>
                                <label> Marketing</label>
                                <select id="tambah_marketing_customer" name="tambah_marketing_customer" class="form-control select2 " required>
                                <option value="">Pilih Marketing</option>
                                <option value="">Andy</option>
                                <option value="">Bily</option>
                                </select> 
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label>Nama Perusahaan</label>
                                <input id="tambah_perusahaan_customer" name="tambah_perusahaan_customer" class="form-control" type="text">
                                <label>Telpon Kantor</label>
                                <input id="tambah_telp_customer" name="tambah_telp_customer" class="form-control" type="text" onkeypress="return angka('evt')" maxlength="12">
                                <label>Email</label>
                                <input id="tambah_email_customer" name="tambah_email_customer" class="form-control" type="email" >
                                <label>Fax</label>
                                <input id="tambah_fax_customer" name="tambah_fax_customer" class="form-control" type="text" onkeypress="return angka('evt')" maxlength="12" >
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                
                                <label>Alamat</label>
                                <textarea id="tambah_alamat_customer" class="form-control" name="tambah_alamat_customer" rows="5" placeholder="Alamat Lengkap""></textarea>
                            </div>
                        </div>
                        </div>
                </div>
                <div class="modal-footer justify-content-between ">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="col-sm-2 form-control btn btn-primary">Tambah</button>
                </div>
            </form>
        </div>
    </div>
  </div>
<!--/ Modal Tambah Customer -->
<!-- Modal Detail Customer -->
  <div class="modal fade" id="modal-detail-customer">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
                  <div class="modal-header bg-info">
                      <h4 class="modal-title">Detail Data Customer</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                  </div>
                  <div class="modal-body">
                          <div class="row">
                          <div class="col-lg-4">
                              <div class="form-group">
                                  <label>ID Customer</label>
                                  <input id="detail_id_customer "name="detail_id_customer"class="form-control" type="text" disabled="" >
                                  <label>Nama Customer </label>
                                  <input id="detail_nama_customer" name="detail_nama_customer" class="form-control" type="text" disabled>
                                  <label>Nomor Customer (WA)</label>
                                  <input id="detail_cp_customer" name="detail_cp_customer" class="form-control" type="text" onkeypress="return angka('evt')" maxlength="12" disabled>
                                  <label> Marketing</label>
                                  <input id="detail_marketing_customer" name="detail_marketing_customer" class="form-control" type="text" disabled>
                              </div>
                          </div>
                          <div class="col-lg-4">
                              <div class="form-group">
                                  <label>Nama Perusahaan</label>
                                  <input id="detail_perusahaan_customer" name="detail_perusahaan_customer" class="form-control" type="text" disabled>
                                  <label>Telpon Kantor</label>
                                  <input id="detail_telp_customer" name="detail_telp_customer" class="form-control" type="text" onkeypress="return angka('evt')" maxlength="12" disabled>
                                  <label>Email</label>
                                  <input id="detail_email_customer" name="detail_email_customer" class="form-control" type="email" disabled>
                                  <label>Fax</label>
                                  <input id="detail_fax_customer" name="detail_fax_customer" class="form-control" type="text" onkeypress="return angka('evt')" maxlength="12" disabled>
                              </div>
                          </div>
                          <div class="col-lg-4">
                              <div class="form-group">
                                  
                                  <label>Alamat</label>
                                  <textarea id="detail_alamat_customer" class="form-control" name="detail_alamat_customer" rows="5" placeholder="Alamat Lengkap"" disabled></textarea>
                              </div>
                          </div>
                          </div>
                  </div>
                  <div class="modal-footer justify-content-between ">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  </div>
          </div>
      </div>
  </div>
<!-- /Modal Detail Customer -->
<!-- MODAL Edit Customer -->
  <div class="modal fade" id="modal-edit-customer">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <form id="editcustomer">
                  <div class="modal-header bg-warning">
                      <h4 class="modal-title">Edit Data Customer</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                  </div>
                  <div class="modal-body">
                          <div class="row">
                          <div class="col-lg-4">
                              <div class="form-group">
                                  <label>ID Customer</label>
                                  <input id="edit_id_customer "name="edit_id_customer"class="form-control" type="text" disabled="" >
                                  <label>Nama Customer </label>
                                  <input id="edit_nama_customer" name="edit_nama_customer" class="form-control" type="text" required>
                                  <label>Nomor Customer (WA)</label>
                                  <input id="edit_cp_customer" name="edit_cp_customer" class="form-control" type="text" onkeypress="return angka('evt')" maxlength="12" required>
                                  <label> Marketing</label>
                                  <select id="edit_marketing_customer" name="edit_marketing_customer" class="form-control select2 " required>
                                  <option value="">Pilih Marketing</option>
                                  <option value="">Andy</option>
                                  <option value="">Bily</option>
                                  </select> 
                              </div>
                          </div>
                          <div class="col-lg-4">
                              <div class="form-group">
                                  <label>Nama Perusahaan</label>
                                  <input id="edit_perusahaan_customer" name="edit_perusahaan_customer" class="form-control" type="text">
                                  <label>Telpon Kantor</label>
                                  <input id="edit_telp_customer" name="edit_telp_customer" class="form-control" type="text" onkeypress="return angka('evt')" maxlength="12">
                                  <label>Email</label>
                                  <input id="edit_email_customer" name="edit_email_customer" class="form-control" type="email" >
                                  <label>Fax</label>
                                  <input id="edit_fax_customer" name="edit_fax_customer" class="form-control" type="text" onkeypress="return angka('evt')" maxlength="12" >
                              </div>
                          </div>
                          <div class="col-lg-4">
                              <div class="form-group">
                                  
                                  <label>Alamat</label>
                                  <textarea id="edit_alamat_customer" class="form-control" name="edit_alamat_customer" rows="5" placeholder="Alamat Lengkap""></textarea>
                              </div>
                          </div>
                          </div>
                  </div>
                  <div class="modal-footer justify-content-between ">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      <button type="submit" class=" col-sm-2 form-control btn btn-warning">Edit</button>
                  </div>
              </form>
          </div>
      </div>
  </div>
<!--/ Modal Edit Customer -->
<!-- MODAL Hapus Customer -->
  <div class="modal fade" id="modal-hapus-customer">
      <div class="modal-dialog modal-sm">
          <form id="hapuscustomer">
              <div class="modal-content">
                  <div class="modal-header bg-danger">
                      <h4 class="modal-title">Hapus Data Customer</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                  </div>
                  <div class="modal-body">
                      <div class="row">
                          <div class="col-lg-12">
                              <div class="form-group">
                                  Apakah Anda Yakin Akan Menghapus Data ini ?
                                  <input id="hapus_id_customer "name="hapus_id_customer"class="form-control" type="text" hidden >
                                  <div class="row">
                                      <label class=" col-md-3">ID </label> 
                                      <h6 class="col-md-6"> 	NP-C-00000357</h6>
                                  </div>
                                  <div class="row">
                                      <label class=" col-md-3">Nama </label> 
                                      <h6 class="col-md-6">ABDUL ROHMAN AL ABDI</h6>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="modal-footer justify-content-between ">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      <button type="submit" class=" col-sm-4 form-control btn btn-danger">Hapus</button>
                  </div>
              </div>
          </form>
      </div>
  </div>
<!--/ Modal Hapus Customer -->
<!--/ MODAL -->

<!-- /MODAL -->
  <!-- /.content-wrapper -->
  <?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<!-- ./wrapper -->
<!-- jQuery -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.colVis.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/sweetalert2/sweetalert2.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/dist')); ?>/js/adminlte.min.js"></script>
<script>
    
    
  $(document).ready(function () {     

    $(function () {
      $("#example1").DataTable({
      "responsive": false, "lengthChange": false, "autoWidth": true,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
      }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });
  });

  function angka(evt){
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))

            return false;
        return true;
    } 

  $(document).on('click','#tambahdata',function(){
    document.getElementById("tambahcustomer").reset();
  });
</script>
</body>
</html>
<?php /**PATH I:\Laravel\NPA\resources\views/S-Admin/data-customer.blade.php ENDPATH**/ ?>