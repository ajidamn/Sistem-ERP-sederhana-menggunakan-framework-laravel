<?php
phpinfo();
?><?php /**PATH I:\Laravel\NPA\resources\views/info.blade.php ENDPATH**/ ?>