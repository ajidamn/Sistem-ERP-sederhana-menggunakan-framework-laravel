<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layout/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/css/buttons.bootstrap4.min.css">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/select2/css/select2.min.css">
<link rel="stylesheet" href="<?php echo e(asset('AdminLTE/plugins')); ?>/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  
  <?php echo $__env->make('layout/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('layout/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Daily Report Marketing</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item "><a href="dashboard">Home</a></li>
              <li class="breadcrumb-item active">Daily Report Marketing</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                    <div class="col-2">
                        <button type="button" data-toggle="modal" data-target="#modal-buat-laporan"class="btn btn-block bg-gradient-primary">Buat Laporan</button>
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                      <th>Tanggal</th>
                      <th>Nama Marketing</th>
                      <th>Waktu Submit</th>
                      <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                      <td>2022-10-10</td>
                      <td>Ikhsan Setiawan</td>
                      <td>17.00</td>
                      <td> 
                        <button type="button" data-toggle="modal" data-target="#modal-laporan"class="btn btn-block bg-gradient-info">Cek Laporan</button>
                      </td>
                    </tr>
                    </tbody>
                    <tfoot>
                    <tr>
                      <th>Tanggal</th>
                      <th>Nama Marketing</th>
                      <th>Waktu Submit</th>
                      <th>Action</th>
                    </tr>
                    </tfoot>
                  </table>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
      </section>
    <!-- /.content -->
  </div>
  <!-- MODAL -->
    <!-- MODAL Preview Laporan -->
    <div class="modal fade" id="modal-laporan">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-info">
            <h4 class="modal-title">Laporan Marketing</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <textarea class="form-control" rows="3" placeholder="Enter ..." disabled="" style="height: 200px;"></textarea>
            </div>
            <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>
    <!-- MODAL Buat Laporan -->
    <div class="modal fade" id="modal-buat-laporan">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-info">
            <h4 class="modal-title">Laporan Marketing</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <form id="tambahlaporanmarketing">
            <div class="modal-body">
                    <div class="row col-lg-12">
                        <div class="form-group">
                            <label>Nama Marketing</label>
                            <select class="form-control select2" style="width:400px">
                              <option selected="selected">Alabama</option>
                              <option>Alaska</option>
                              <option>California</option>
                              <option>Delaware</option>
                              <option>Tennessee</option>
                              <option>Texas</option>
                              <option>Washington</option>
                            </select>
                          </div>
                    </div>
                    <div class="row col-lg-12">
                        <div class="form-group">
                            <label> Laporan </label>
                            <textarea class="form-control" rows="5" placeholder="Tulis Laporan Anda"  style="height: 200px; width: 400px"></textarea>
                        </div>
                    </div>
                
            </div>
            <div class="modal-footer justify-content-between ">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        </form>
        </div>
        </div>
    </div>
  <!-- /MODAL -->
  <!-- /.content-wrapper -->
  <?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<!-- ./wrapper -->

<?php echo $__env->make('layout/script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- DataTables  & Plugins -->
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.bootstrap4.min.js"></script>

<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo e(asset('AdminLTE/plugins')); ?>/datatables-buttons/js/buttons.colVis.min.js"></script>
<script>
    $(function () {


        $("#example1").DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
        $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "responsive": true,
        });
  });
</script>
</body>
</html>
<?php /**PATH I:\Laravel\NPA\resources\views/S-Admin/laporanmarketing.blade.php ENDPATH**/ ?>